extends Node2D
## Pembangun lintasan prosedural: spline Catmull-Rom -> mesh jalan, kerb, dinding
## bertabrakan, dekorasi (MultiMesh) dan profil kecepatan untuk AI.

const STEP := 50.0
const GRID := 400.0
const DECOR_TEX := {
	"tree": "res://assets/fx/tree.png",
	"tree2": "res://assets/fx/tree2.png",
	"pine": "res://assets/fx/pine.png",
	"bush": "res://assets/fx/bush.png",
	"rock": "res://assets/fx/rock.png",
	"container": "res://assets/fx/container.png",
	"roof": "res://assets/fx/roof.png",
	"tcone": "res://assets/fx/tcone.png",
}
const CANOPY := ["tree", "tree2", "pine"]
const GROUND_TEX := {
	"grass": "res://assets/tex/grass.png",
	"forest": "res://assets/tex/forest.png",
	"sand": "res://assets/tex/sand.png",
	"concrete": "res://assets/tex/concrete.png",
}
const BARRIER_TEX := {
	"rw": "res://assets/fx/barrier_rw.png",
	"yb": "res://assets/fx/barrier_yb.png",
	"gg": "res://assets/fx/barrier_gg.png",
}

var def: Dictionary = {}
var pts := PackedVector2Array()
var tans := PackedVector2Array()
var nors := PackedVector2Array()     # vektor sisi kanan arah laju
var curv := PackedFloat32Array()
var corner_speed := PackedFloat32Array()
var count: int = 0
var length: float = 0.0
var step_len: float = STEP
var half_w: float = 140.0
var wall_off: float = 220.0
var bounds := Rect2()
var quality: int = 2

var _rng := RandomNumberGenerator.new()
var _grid: Dictionary = {}
var _quad: ArrayMesh = null


## Sampling spline tertutup menjadi titik berjarak seragam.
static func sample(ctrl: Array, step: float = STEP) -> Dictionary:
	var n: int = ctrl.size()
	var p: Array[Vector2] = []
	for c in ctrl:
		p.append(Vector2(float(c[0]), float(c[1])))
	var dense := PackedVector2Array()
	var sub: int = 24
	for i in range(n):
		var p0: Vector2 = p[(i - 1 + n) % n]
		var p1: Vector2 = p[i]
		var p2: Vector2 = p[(i + 1) % n]
		var p3: Vector2 = p[(i + 2) % n]
		for k in range(sub):
			var t: float = float(k) / float(sub)
			var t2: float = t * t
			var t3: float = t2 * t
			var q: Vector2 = 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)
			dense.append(q)
	dense.append(dense[0])
	var cum := PackedFloat32Array()
	cum.resize(dense.size())
	cum[0] = 0.0
	for i in range(1, dense.size()):
		cum[i] = cum[i - 1] + dense[i].distance_to(dense[i - 1])
	var total: float = cum[dense.size() - 1]
	var cnt: int = maxi(8, roundi(total / step))
	var sl: float = total / float(cnt)
	var out := PackedVector2Array()
	out.resize(cnt)
	var j: int = 0
	for i in range(cnt):
		var s: float = float(i) * sl
		while j < dense.size() - 2 and cum[j + 1] < s:
			j += 1
		var seg: float = cum[j + 1] - cum[j]
		var f: float = 0.0
		if seg > 0.0001:
			f = (s - cum[j]) / seg
		out[i] = dense[j].lerp(dense[j + 1], f)
	return {"pts": out, "length": total, "step": sl}


func build(map_def: Dictionary, q: int) -> void:
	def = map_def
	quality = clampi(q, 0, 2)
	_rng.seed = hash(str(def["id"]))
	var s: Dictionary = sample(def["pts"])
	pts = s["pts"]
	length = float(s["length"])
	step_len = float(s["step"])
	count = pts.size()
	half_w = float(def["width"]) * 0.5
	wall_off = half_w + float(def["shoulder"])
	_compute_frames()
	_build_grid()
	_build_ground()
	_build_road()
	_build_walls()
	_build_decor()
	_build_lamps()
	_compute_speeds()


# ---------------------------------------------------------------- geometri dasar
func _compute_frames() -> void:
	tans.resize(count)
	nors.resize(count)
	curv.resize(count)
	var mn := pts[0]
	var mx := pts[0]
	for i in range(count):
		var a: Vector2 = pts[(i + 1) % count] - pts[(i - 1 + count) % count]
		var t: Vector2 = a.normalized()
		tans[i] = t
		nors[i] = Vector2(-t.y, t.x)
		mn = Vector2(minf(mn.x, pts[i].x), minf(mn.y, pts[i].y))
		mx = Vector2(maxf(mx.x, pts[i].x), maxf(mx.y, pts[i].y))
	for i in range(count):
		var a0: float = tans[(i - 1 + count) % count].angle()
		var a1: float = tans[(i + 1) % count].angle()
		curv[i] = wrapf(a1 - a0, -PI, PI) / (2.0 * step_len)
	bounds = Rect2(mn, mx - mn).grow(wall_off + 900.0)


func _build_grid() -> void:
	_grid.clear()
	for i in range(count):
		var key := Vector2i(floori(pts[i].x / GRID), floori(pts[i].y / GRID))
		if not _grid.has(key):
			_grid[key] = []
		_grid[key].append(i)


## true jika titik cukup jauh dari seluruh garis tengah lintasan.
func _is_clear(p: Vector2, min_d: float) -> bool:
	var r: int = ceili(min_d / GRID)
	var cx: int = floori(p.x / GRID)
	var cy: int = floori(p.y / GRID)
	var md2: float = min_d * min_d
	for gx in range(cx - r, cx + r + 1):
		for gy in range(cy - r, cy + r + 1):
			var key := Vector2i(gx, gy)
			if _grid.has(key):
				for i in _grid[key]:
					if p.distance_squared_to(pts[i]) < md2:
						return false
	return true


func _quad_mesh() -> ArrayMesh:
	if _quad == null:
		var v := PackedVector2Array([Vector2(-0.5, -0.5), Vector2(0.5, -0.5), Vector2(0.5, 0.5), Vector2(-0.5, 0.5)])
		var uv := PackedVector2Array([Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)])
		var idx := PackedInt32Array([0, 1, 2, 0, 2, 3])
		_quad = _mesh_from(v, idx, uv)
	return _quad


func _mesh_from(verts: PackedVector2Array, indices: PackedInt32Array, uvs: PackedVector2Array = PackedVector2Array()) -> ArrayMesh:
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	if uvs.size() == verts.size():
		arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return m


func _add_quad(verts: PackedVector2Array, idx: PackedInt32Array, a: Vector2, b: Vector2, c: Vector2, d: Vector2) -> void:
	var base: int = verts.size()
	verts.append(a)
	verts.append(b)
	verts.append(c)
	verts.append(d)
	idx.append(base)
	idx.append(base + 1)
	idx.append(base + 2)
	idx.append(base)
	idx.append(base + 2)
	idx.append(base + 3)


## Strip melingkar di sepanjang lintasan antara offset oa..ob (tanda + = sisi kanan).
func _ring_strip(oa: float, ob: float, with_uv: bool = false) -> ArrayMesh:
	var verts := PackedVector2Array()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	for i in range(count):
		var a: Vector2 = pts[i] + nors[i] * oa
		var b: Vector2 = pts[i] + nors[i] * ob
		verts.append(a)
		verts.append(b)
		if with_uv:
			uvs.append(a / Global.TILE)
			uvs.append(b / Global.TILE)
	for i in range(count):
		var j: int = (i + 1) % count
		var a0: int = i * 2
		var b0: int = j * 2
		idx.append(a0)
		idx.append(a0 + 1)
		idx.append(b0)
		idx.append(a0 + 1)
		idx.append(b0 + 1)
		idx.append(b0)
	return _mesh_from(verts, idx, uvs)


func _mi(mesh: Mesh, tex: Texture2D, tint: Color, z: int, additive: bool = false) -> MeshInstance2D:
	var m := MeshInstance2D.new()
	m.mesh = mesh
	if tex != null:
		m.texture = tex
		m.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	m.modulate = tint
	m.z_index = z
	if additive:
		var mat := CanvasItemMaterial.new()
		mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		m.material = mat
	add_child(m)
	return m


# ---------------------------------------------------------------- bangun visual
func _build_ground() -> void:
	var tex: Texture2D = load(GROUND_TEX[def["ground"]])
	var r: Rect2 = bounds
	var v := PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])
	var uv := PackedVector2Array()
	for p in v:
		uv.append(p / Global.TILE)
	var idx := PackedInt32Array([0, 1, 2, 0, 2, 3])
	_mi(_mesh_from(v, idx, uv), tex, Color(def["ground_tint"]), -10)


func _build_road() -> void:
	var road_tex: Texture2D = load("res://assets/tex/asphalt.png")
	_mi(_ring_strip(-half_w - 26.0, -half_w), null, Color(0, 0, 0, 0.22), -9)
	_mi(_ring_strip(half_w, half_w + 26.0), null, Color(0, 0, 0, 0.22), -9)
	_mi(_ring_strip(-half_w, half_w, true), road_tex, Color(def["road_tint"]), -8)

	var line_col := Color(def["line"])
	_mi(_ring_strip(half_w - 22.0, half_w - 12.0), null, line_col, -7)
	_mi(_ring_strip(-half_w + 12.0, -half_w + 22.0), null, line_col, -7)

	# garis putus-putus tengah
	var dv := PackedVector2Array()
	var di := PackedInt32Array()
	for i in range(0, count, 3):
		var j: int = (i + 1) % count
		_add_quad(dv, di, pts[i] - nors[i] * 5.0, pts[i] + nors[i] * 5.0, pts[j] + nors[j] * 5.0, pts[j] - nors[j] * 5.0)
	_mi(_mesh_from(dv, di), null, Color(line_col.r, line_col.g, line_col.b, 0.75), -7)

	# kerb belang
	if bool(def["kerbs"]):
		for side in [1.0, -1.0]:
			var ka_v := PackedVector2Array()
			var ka_i := PackedInt32Array()
			var kb_v := PackedVector2Array()
			var kb_i := PackedInt32Array()
			var o0: float = half_w * side
			var o1: float = (half_w + 20.0) * side
			for i in range(count):
				var j: int = (i + 1) % count
				var qa: Vector2 = pts[i] + nors[i] * o0
				var qb: Vector2 = pts[i] + nors[i] * o1
				var qc: Vector2 = pts[j] + nors[j] * o1
				var qd: Vector2 = pts[j] + nors[j] * o0
				if (i / 2) % 2 == 0:
					_add_quad(ka_v, ka_i, qa, qb, qc, qd)
				else:
					_add_quad(kb_v, kb_i, qa, qb, qc, qd)
			_mi(_mesh_from(ka_v, ka_i), null, Color(def["kerb1"]), -7)
			_mi(_mesh_from(kb_v, kb_i), null, Color(def["kerb2"]), -7)

	# neon tepi jalan (aditif)
	if bool(def["neon"]):
		var c1 := Color(def["kerb1"])
		var c2 := Color(def["kerb2"])
		_mi(_ring_strip(-half_w - 4.0, -half_w + 8.0), null, Color(c1.r, c1.g, c1.b, 0.9), -6, true)
		_mi(_ring_strip(half_w - 8.0, half_w + 4.0), null, Color(c2.r, c2.g, c2.b, 0.9), -6, true)

	# garis start / finis (papan catur)
	var cells: int = ceili(half_w * 2.0 / 28.0)
	var cw: float = half_w * 2.0 / float(cells)
	var wv := PackedVector2Array()
	var wi := PackedInt32Array()
	var bv := PackedVector2Array()
	var bi := PackedInt32Array()
	var t0: Vector2 = tans[0]
	var n0: Vector2 = nors[0]
	var base: Vector2 = pts[0] - t0 * 28.0
	for c in range(cells):
		for r in range(2):
			var p0: Vector2 = base + n0 * (-half_w + float(c) * cw) + t0 * (float(r) * 28.0)
			var p1: Vector2 = p0 + n0 * cw
			var p2: Vector2 = p1 + t0 * 28.0
			var p3: Vector2 = p0 + t0 * 28.0
			if (c + r) % 2 == 0:
				_add_quad(wv, wi, p0, p1, p2, p3)
			else:
				_add_quad(bv, bi, p0, p1, p2, p3)
	_mi(_mesh_from(wv, wi), null, Color(0.96, 0.96, 0.96), -6)
	_mi(_mesh_from(bv, bi), null, Color(0.05, 0.05, 0.06), -6)


func _build_walls() -> void:
	var body := StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var tex: Texture2D = load(BARRIER_TEX[def["barrier"]])
	for side in [1.0, -1.0]:
		var ring := PackedVector2Array()
		for i in range(count):
			ring.append(pts[i] + nors[i] * wall_off * side)
		var segs := PackedVector2Array()
		for i in range(count):
			segs.append(ring[i])
			segs.append(ring[(i + 1) % count])
		var shape := ConcavePolygonShape2D.new()
		shape.segments = segs
		var cs := CollisionShape2D.new()
		cs.shape = shape
		body.add_child(cs)

		var ln := Line2D.new()
		ln.points = ring
		ln.closed = true
		ln.width = 18.0
		ln.texture = tex
		ln.texture_mode = Line2D.LINE_TEXTURE_TILE
		ln.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
		ln.joint_mode = Line2D.LINE_JOINT_ROUND
		ln.round_precision = 4
		ln.default_color = Color.WHITE
		ln.z_index = -2
		add_child(ln)


# ---------------------------------------------------------------- dekorasi
func _multimesh(tex: Texture2D, items: Array, z: int, additive: bool = false) -> void:
	if items.is_empty():
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_2D
	mm.use_colors = true
	mm.mesh = _quad_mesh()
	mm.instance_count = items.size()
	for k in range(items.size()):
		var it: Array = items[k]
		var pos: Vector2 = it[0]
		var rot: float = it[1]
		var sz: Vector2 = it[2]
		var col: Color = it[3]
		var xf := Transform2D(rot, pos).scaled_local(sz)
		mm.set_instance_transform_2d(k, xf)
		mm.set_instance_color(k, col)
	var mmi := MultiMeshInstance2D.new()
	mmi.multimesh = mm
	mmi.texture = tex
	mmi.z_index = z
	if additive:
		var mat := CanvasItemMaterial.new()
		mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		mmi.material = mat
	add_child(mmi)


func _build_decor() -> void:
	var qmul: float = [0.35, 0.7, 1.0][quality]
	var dry: bool = str(def["ground"]) == "sand"
	var box_colors: Array[Color] = [Color(0.9, 0.25, 0.2), Color(0.2, 0.45, 0.85), Color(0.95, 0.65, 0.15), Color(0.2, 0.65, 0.4), Color(0.75, 0.75, 0.8)]
	for d in def["deco"]:
		var kind: String = d[0]
		var n: int = int(float(d[1]) * qmul)
		if n <= 0:
			continue
		var tex: Texture2D = load(DECOR_TEX[kind])
		var aspect: float = float(tex.get_height()) / float(tex.get_width())
		var items: Array = []
		var tries: int = 0
		while items.size() < n and tries < n * 8:
			tries += 1
			var i: int = _rng.randi() % count
			var side: float = 1.0 if _rng.randf() < 0.5 else -1.0
			var extra: float = lerpf(float(d[2]), float(d[3]), _rng.randf())
			var pos: Vector2 = pts[i] + nors[i] * side * (wall_off + extra)
			pos += Vector2(_rng.randf_range(-40.0, 40.0), _rng.randf_range(-40.0, 40.0))
			var sz: float = lerpf(float(d[4]), float(d[5]), _rng.randf())
			if not _is_clear(pos, wall_off + sz * 0.5 + 36.0):
				continue
			var rot: float = _rng.randf() * TAU
			var col := Color.WHITE
			var scl := Vector2(sz, sz * aspect)
			match kind:
				"container":
					rot = tans[i].angle() + (0.0 if _rng.randf() < 0.5 else PI * 0.5)
					col = box_colors[_rng.randi() % box_colors.size()]
				"roof":
					rot = tans[i].angle()
					var g: float = _rng.randf_range(0.7, 1.0)
					col = Color(g, g, g)
				_:
					var b: float = _rng.randf_range(0.8, 1.1)
					col = Color(b, b, b)
					if dry and (kind == "tree2" or kind == "bush"):
						col = Color(b * 1.0, b * 0.82, b * 0.5)
			items.append([pos, rot, scl, col])
		_multimesh(tex, items, 10 if CANOPY.has(kind) else 1)


func _build_lamps() -> void:
	if not bool(def["lamps"]):
		return
	var glow: Texture2D = load("res://assets/fx/glow.png")
	var gc := Color(def["glow"])
	var halo: Array = []
	var core: Array = []
	for i in range(0, count, 8):
		for side in [1.0, -1.0]:
			var pos: Vector2 = pts[i] + nors[i] * side * (wall_off + 40.0)
			if not _is_clear(pos, wall_off + 20.0):
				continue
			halo.append([pos, 0.0, Vector2(440, 440), Color(gc.r, gc.g, gc.b, 0.5)])
			core.append([pos, 0.0, Vector2(54, 54), Color(1, 1, 1, 0.95)])
	_multimesh(glow, halo, 6, true)
	_multimesh(glow, core, 6, true)


# ---------------------------------------------------------------- profil AI
func _compute_speeds() -> void:
	corner_speed.resize(count)
	for i in range(count):
		var k: float = 0.0
		for j in range(-3, 4):
			k = maxf(k, absf(curv[posmod(i + j, count)]))
		corner_speed[i] = minf(1500.0, sqrt(1700.0 / maxf(k, 0.00001)))
	for _pass in range(3):
		for i in range(count - 1, -1, -1):
			var nx: float = corner_speed[(i + 1) % count]
			corner_speed[i] = minf(corner_speed[i], sqrt(nx * nx + 2.0 * 1100.0 * step_len))


# ---------------------------------------------------------------- query
func nearest(p: Vector2, hint: int, window: int = 12) -> int:
	var best: int = hint
	var bd: float = INF
	for j in range(-window, window * 2):
		var k: int = posmod(hint + j, count)
		var d: float = p.distance_squared_to(pts[k])
		if d < bd:
			bd = d
			best = k
	return best


func nearest_global(p: Vector2) -> int:
	var best: int = 0
	var bd: float = INF
	for k in range(count):
		var d: float = p.distance_squared_to(pts[k])
		if d < bd:
			bd = d
			best = k
	return best


func lateral(p: Vector2, idx: int) -> float:
	return (p - pts[idx]).dot(nors[idx])


## Posisi awal grid: slot 0 = depan.
func grid_slot(slot: int) -> Dictionary:
	var row: int = slot / 2
	var side: float = -1.0 if slot % 2 == 0 else 1.0
	var back: float = 110.0 + float(row) * 150.0 + (50.0 if slot % 2 == 1 else 0.0)
	var pos: Vector2 = pts[0] - tans[0] * back + nors[0] * side * half_w * 0.3
	return {"pos": pos, "rot": tans[0].angle()}
