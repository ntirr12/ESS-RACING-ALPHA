extends Control
## Shell menu utama: panel (utama, garasi, peta, pengaturan, cara main) + transisi.

const UIKit := preload("res://scripts/ui_kit.gd")
const BgScript := preload("res://scripts/menu_bg.gd")
const GaragePanel := preload("res://scripts/garage_panel.gd")
const MapPanel := preload("res://scripts/map_panel.gd")
const SettingsPanel := preload("res://scripts/settings_panel.gd")

var panels: Dictionary = {}
var current: String = "main"
var bg = null

var _margin: MarginContainer
var _content: Control
var _coin_lbl: Label
var _car_lbl: Label
var _toast: Label
var _toast_tw: Tween = null
var _busy: bool = false


func _ready() -> void:
	theme = UIKit.make_theme()
	UIKit.fill(self)
	var cl := CanvasLayer.new()
	cl.layer = -1
	add_child(cl)
	bg = BgScript.new()
	cl.add_child(bg)

	_margin = MarginContainer.new()
	add_child(_margin)
	UIKit.fill(_margin)
	_content = Control.new()
	_margin.add_child(_content)

	panels["main"] = _build_main()
	panels["howto"] = _build_howto()
	var gp := GaragePanel.new()
	gp.menu = self
	panels["garage"] = gp
	var mp := MapPanel.new()
	mp.menu = self
	panels["maps"] = mp
	var sp := SettingsPanel.new()
	sp.menu = self
	panels["settings"] = sp
	for k in panels.keys():
		var p: Control = panels[k]
		if p.get_parent() == null:
			_content.add_child(p)
		UIKit.fill(p)
		p.visible = (k == "main")
		p.modulate.a = 1.0 if k == "main" else 0.0

	_toast = UIKit.label("", 28, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 6)
	_toast.modulate.a = 0.0
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_toast)

	resized.connect(_apply_margins)
	_apply_margins()
	Save.coins_changed.connect(func(_v: int) -> void: refresh_coins())
	refresh_coins()
	Sfx.play_music("music_menu")
	Sfx.duck_music(false)


func _apply_margins() -> void:
	var m: Vector4 = UIKit.safe_margins(size)
	_margin.add_theme_constant_override("margin_left", int(m.x))
	_margin.add_theme_constant_override("margin_top", int(m.y))
	_margin.add_theme_constant_override("margin_right", int(m.z))
	_margin.add_theme_constant_override("margin_bottom", int(m.w))
	_toast.position = Vector2(size.x * 0.5 - 400.0, size.y - 120.0)
	_toast.size = Vector2(800.0, 50.0)


func go(target: String) -> void:
	if target == current or _busy or not panels.has(target):
		return
	_busy = true
	var old: Control = panels[current]
	var nw: Control = panels[target]
	current = target
	var tw := create_tween()
	tw.tween_property(old, "modulate:a", 0.0, 0.1)
	tw.tween_callback(func() -> void:
		old.visible = false
		nw.visible = true
		nw.modulate.a = 0.0
		if nw.has_method("on_show"):
			nw.on_show())
	tw.tween_property(nw, "modulate:a", 1.0, 0.16)
	tw.tween_callback(func() -> void: _busy = false)


func toast(text: String, col: Color = Color.WHITE) -> void:
	_toast.text = text
	_toast.add_theme_color_override("font_color", col)
	_toast.modulate.a = 1.0
	if _toast_tw != null:
		_toast_tw.kill()
	_toast_tw = create_tween()
	_toast_tw.tween_interval(1.4)
	_toast_tw.tween_property(_toast, "modulate:a", 0.0, 0.4)


func refresh_coins() -> void:
	if _coin_lbl != null:
		_coin_lbl.text = Global.fmt_int(Save.coins)
	if _car_lbl != null:
		_car_lbl.text = String(Global.CARS[Global.selected_car]["name"]).to_upper()
	if bg != null:
		bg.set_car(Global.selected_car)


## Widget koin (dipakai berbagai panel).
func make_coin_chip() -> PanelContainer:
	var chip := UIKit.panel(Color(0, 0, 0, 0.45), 30, 8)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 8)
	chip.add_child(hb)
	hb.add_child(UIKit.CoinIcon.new())
	var l := UIKit.label(Global.fmt_int(Save.coins), 30, UIKit.C_GOLD)
	hb.add_child(l)
	Save.coins_changed.connect(func(_v: int) -> void:
		if is_instance_valid(l):
			l.text = Global.fmt_int(Save.coins))
	return chip


func _build_main() -> Control:
	var p := Control.new()
	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 12)
	left.custom_minimum_size = Vector2(430, 0)
	p.add_child(left)
	left.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	left.offset_right = 430.0

	left.add_child(UIKit.spacer(10))
	left.add_child(UIKit.label("TP", 60, UIKit.C_PINK, HORIZONTAL_ALIGNMENT_LEFT, 8))
	var title := UIKit.label("DRIFT", 120, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_LEFT, 12)
	title.custom_minimum_size = Vector2(0, 100)
	left.add_child(title)
	left.add_child(UIKit.label("TOP-DOWN DRIFT RACING", 22, UIKit.C_DIM))
	left.add_child(UIKit.spacer(14, true))
	left.add_child(UIKit.button("MAIN", 40, 1, Vector2(0, 92), func() -> void: go("maps")))
	left.add_child(UIKit.button("GARASI", 30, 0, Vector2(0, 68), func() -> void: go("garage")))
	left.add_child(UIKit.button("PENGATURAN", 28, 0, Vector2(0, 68), func() -> void: go("settings")))
	left.add_child(UIKit.button("CARA BERMAIN", 28, 0, Vector2(0, 68), func() -> void: go("howto")))
	if not OS.has_feature("web"):
		left.add_child(UIKit.button("KELUAR", 26, 2, Vector2(0, 60), func() -> void: Global.quit_game()))
	left.add_child(UIKit.label("v" + Global.VERSION, 18, UIKit.C_DIM))

	var top_right := HBoxContainer.new()
	p.add_child(top_right)
	top_right.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	top_right.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	var chip := UIKit.panel(Color(0, 0, 0, 0.45), 30, 8)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 8)
	chip.add_child(hb)
	hb.add_child(UIKit.CoinIcon.new())
	_coin_lbl = UIKit.label(Global.fmt_int(Save.coins), 32, UIKit.C_GOLD)
	hb.add_child(_coin_lbl)
	top_right.add_child(chip)

	var bottom_right := VBoxContainer.new()
	bottom_right.alignment = BoxContainer.ALIGNMENT_END
	bottom_right.add_theme_constant_override("separation", 8)
	p.add_child(bottom_right)
	bottom_right.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	bottom_right.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	bottom_right.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_car_lbl = UIKit.label("", 34, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT, 6)
	bottom_right.add_child(_car_lbl)
	bottom_right.add_child(UIKit.button("GANTI MOBIL", 22, 0, Vector2(240, 54), func() -> void: go("garage")))
	return p


func _build_howto() -> Control:
	var p := Control.new()
	var vb := VBoxContainer.new()
	p.add_child(vb)
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var head := HBoxContainer.new()
	vb.add_child(head)
	head.add_child(UIKit.button("KEMBALI", 26, 0, Vector2(200, 64), func() -> void: go("main")))
	var t := UIKit.label("CARA BERMAIN", 46, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	head.add_child(UIKit.spacer(0))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 14)
	sc.add_child(inner)
	var items: Array = [
		["KONTROL", "Tombol kiri/kanan untuk setir. Gas otomatis (bisa dimatikan di Pengaturan). Atau pilih mode Joystick: geser untuk mengarahkan mobil."],
		["DRIFT", "Tahan tombol DRIFT (handbrake) sambil belok untuk melempar ekor mobil. Lepas tombol lalu beri gas untuk keluar tikungan. Sudut dan kecepatan yang lebih besar memberi skor lebih tinggi."],
		["KOMBO", "Drift beruntun menaikkan pengganda hingga x8. Skor dibank saat drift berhenti sekitar 1 detik. Menabrak dinding keras membuat rantai gagal."],
		["NITRO", "Drift mengisi bar nitro. Tekan tombol petir untuk dorongan kecepatan sementara."],
		["MODE", "Balapan: lawan 3 AI. Time Attack: kejar lap tercepat dan raih medali. Drift Challenge: 120 detik untuk skor drift setinggi mungkin."],
		["KOIN", "Dapatkan koin dari balapan, medali, dan skor drift. Pakai untuk membeli mobil, membuka lintasan, mengecat, dan upgrade (mesin, ban, nitro)."],
		["TIPS", "Rumput memperlambat mobil. Dinding bisa dipakai menahan putaran, tapi tabrakan keras memotong kecepatan. Terjebak? Tekan tombol panah melingkar di kanan atas untuk reset ke jalur."],
	]
	for it in items:
		var card := UIKit.panel(UIKit.C_PANEL, 16, 16)
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 4)
		card.add_child(cv)
		cv.add_child(UIKit.label(String(it[0]), 26, UIKit.C_PINK))
		var body := UIKit.label(String(it[1]), 24, UIKit.C_TEXT)
		body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		body.custom_minimum_size = Vector2(300, 0)
		body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		cv.add_child(body)
		inner.add_child(card)
	return p


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if current != "main":
			go("main")
		else:
			Global.quit_game()
