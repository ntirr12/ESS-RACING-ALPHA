extends Control
## Garasi: pilih/beli mobil, upgrade, cat.

const UIKit := preload("res://scripts/ui_kit.gd")

var menu = null
var idx: int = 0

var _tex: TextureRect
var _name: Label
var _tag: Label
var _desc: Label
var _action: Button
var _bars: Array = []
var _up_rows: Array = []
var _paint_box: HBoxContainer
var _upgrade_note: Label
var _bob: Tween = null


func _ready() -> void:
	var root := VBoxContainer.new()
	add_child(root)
	UIKit.fill(root)

	var head := HBoxContainer.new()
	root.add_child(head)
	head.add_child(UIKit.button("KEMBALI", 26, 0, Vector2(200, 64), func() -> void: menu.go("main")))
	var t := UIKit.label("GARASI", 46, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	head.add_child(menu.make_coin_chip())

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 20)
	root.add_child(body)

	# ---- kiri: pratinjau
	var left := UIKit.panel(UIKit.C_PANEL, 22, 16)
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 1.5
	body.add_child(left)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 6)
	left.add_child(lv)

	var prev := HBoxContainer.new()
	prev.size_flags_vertical = Control.SIZE_EXPAND_FILL
	lv.add_child(prev)
	prev.add_child(UIKit.arrow_button(-1, func() -> void: _step(-1)))
	_tex = TextureRect.new()
	_tex.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tex.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tex.custom_minimum_size = Vector2(300, 170)
	_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_tex.resized.connect(func() -> void: _tex.pivot_offset = _tex.size * 0.5)
	prev.add_child(_tex)
	prev.add_child(UIKit.arrow_button(1, func() -> void: _step(1)))

	_tag = UIKit.label("", 22, UIKit.C_PINK, HORIZONTAL_ALIGNMENT_CENTER)
	_name = UIKit.label("", 46, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 6)
	_desc = UIKit.label("", 22, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_CENTER)
	_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_desc.custom_minimum_size = Vector2(300, 60)
	lv.add_child(_tag)
	lv.add_child(_name)
	lv.add_child(_desc)
	_action = UIKit.button("", 32, 1, Vector2(0, 74), _on_action)
	lv.add_child(_action)

	# ---- kanan: statistik, upgrade, cat
	var sc := ScrollContainer.new()
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(sc)
	var rv := VBoxContainer.new()
	rv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rv.add_theme_constant_override("separation", 10)
	sc.add_child(rv)

	var stat_panel := UIKit.panel(UIKit.C_PANEL, 18, 14)
	rv.add_child(stat_panel)
	var sv := VBoxContainer.new()
	stat_panel.add_child(sv)
	sv.add_child(UIKit.label("STATISTIK", 22, UIKit.C_PINK))
	var cols: Array = [UIKit.C_CYAN, UIKit.C_GREEN, UIKit.C_GOLD, UIKit.C_PINK]
	var names: Array = ["Kecepatan", "Akselerasi", "Handling", "Drift"]
	for i in range(4):
		var b := UIKit.stat_bar(String(names[i]), 0.0, cols[i], 140.0)
		sv.add_child(b)
		_bars.append(b)

	var up_panel := UIKit.panel(UIKit.C_PANEL, 18, 14)
	rv.add_child(up_panel)
	var uv := VBoxContainer.new()
	up_panel.add_child(uv)
	uv.add_child(UIKit.label("UPGRADE", 22, UIKit.C_PINK))
	_upgrade_note = UIKit.label("Beli mobil ini untuk membuka upgrade.", 20, UIKit.C_DIM)
	uv.add_child(_upgrade_note)
	for i in range(Global.UPGRADES.size()):
		var row := HBoxContainer.new()
		row.custom_minimum_size = Vector2(0, 62)
		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		info.add_theme_constant_override("separation", 0)
		info.add_child(UIKit.label(String(Global.UPGRADES[i]["name"]), 24, UIKit.C_TEXT))
		var pb := ProgressBar.new()
		pb.min_value = 0.0
		pb.max_value = float(Global.MAX_UPGRADE)
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(0, 12)
		pb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		pb.add_theme_stylebox_override("fill", UIKit.sb(UIKit.C_GOLD, 5))
		info.add_child(pb)
		row.add_child(info)
		var ub := UIKit.button("", 22, 3, Vector2(170, 56), func() -> void: _on_upgrade(i))
		row.add_child(ub)
		uv.add_child(row)
		_up_rows.append({"bar": pb, "btn": ub})

	var paint_panel := UIKit.panel(UIKit.C_PANEL, 18, 14)
	rv.add_child(paint_panel)
	var pv := VBoxContainer.new()
	paint_panel.add_child(pv)
	pv.add_child(UIKit.label("CAT", 22, UIKit.C_PINK))
	_paint_box = HBoxContainer.new()
	_paint_box.add_theme_constant_override("separation", 8)
	pv.add_child(_paint_box)

	idx = Global.selected_car
	_refresh(false)


func on_show() -> void:
	idx = Global.selected_car
	_refresh(false)


func _step(d: int) -> void:
	idx = (idx + d + Global.CARS.size()) % Global.CARS.size()
	_refresh(true)


func _stat_values(id: int) -> Array:
	var s: Dictionary = Global.car_stats(id)
	var speed: float = float(s["max"]) / 1350.0
	var accel: float = float(s["acc"]) / 1150.0
	var handling: float = 0.55 * float(s["turn"]) / 3.6 + 0.45 * float(s["grip"]) / 12.5
	var drift: float = 0.5 * float(s["dbias"]) / 0.95 + 0.5 * (2.7 - float(s["dgrip"])) / 1.3
	return [speed, accel, handling, drift]


func _refresh(animate: bool) -> void:
	var c: Dictionary = Global.CARS[idx]
	var owned: bool = Save.has_car(idx)
	_tex.texture = load(String(c["tex"]))
	var pc: Array = Global.PAINTS
	_tex.modulate = Color(String(pc[Save.car_paint(idx)]["color"]))
	_name.text = String(c["name"]).to_upper()
	_tag.text = String(c["tag"])
	_desc.text = String(c["desc"])
	if animate:
		UIKit.pop(_tex)
	_start_bob()

	var vals: Array = _stat_values(idx)
	for i in range(4):
		UIKit.set_stat_bar(_bars[i], float(vals[i]))

	# tombol aksi
	if owned:
		if Global.selected_car == idx:
			_action.text = "TERPILIH"
			_action.disabled = true
			UIKit.style_button(_action, UIKit.C_GREEN)
		else:
			_action.text = "PILIH"
			_action.disabled = false
			UIKit.style_button(_action, UIKit.C_CYAN)
	else:
		_action.text = "BELI  " + Global.fmt_int(int(c["price"]))
		_action.disabled = false
		UIKit.style_button(_action, UIKit.C_GOLD)

	# upgrade
	_upgrade_note.visible = not owned
	var lv: Array = Save.car_upgrades(idx)
	for i in range(_up_rows.size()):
		var lvl: int = int(lv[i])
		var row: Dictionary = _up_rows[i]
		var bar: ProgressBar = row["bar"]
		var btn: Button = row["btn"]
		bar.value = float(lvl)
		bar.modulate.a = 1.0 if owned else 0.35
		if not owned:
			btn.text = "TERKUNCI"
			btn.disabled = true
		elif lvl >= Global.MAX_UPGRADE:
			btn.text = "MAKS"
			btn.disabled = true
		else:
			btn.text = Global.fmt_int(Global.upgrade_cost(idx, i))
			btn.disabled = false

	# cat
	for ch in _paint_box.get_children():
		ch.queue_free()
	var cur: int = Save.car_paint(idx)
	for i in range(pc.size()):
		var col := Color(String(pc[i]["color"]))
		var sw := Button.new()
		sw.custom_minimum_size = Vector2(58, 58)
		sw.focus_mode = Control.FOCUS_NONE
		var sel: bool = (i == cur)
		sw.add_theme_stylebox_override("normal", UIKit.sb(col, 14, Color.WHITE if sel else Color(0, 0, 0, 0.5), 5 if sel else 2))
		sw.add_theme_stylebox_override("hover", UIKit.sb(col.lightened(0.15), 14, Color.WHITE, 4))
		sw.add_theme_stylebox_override("pressed", UIKit.sb(col.darkened(0.2), 14, Color.WHITE, 4))
		sw.disabled = not owned
		sw.pressed.connect(func() -> void: _on_paint(i))
		_paint_box.add_child(sw)


func _start_bob() -> void:
	if _bob != null:
		_bob.kill()
	_tex.rotation = 0.0
	_bob = _tex.create_tween().set_loops()
	_bob.tween_property(_tex, "rotation_degrees", 1.6, 1.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_bob.tween_property(_tex, "rotation_degrees", -1.6, 1.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _on_action() -> void:
	if Save.has_car(idx):
		Global.selected_car = idx
		Global.remember_selection()
		Sfx.play("select")
		menu.refresh_coins()
		_refresh(false)
		return
	var price: int = int(Global.CARS[idx]["price"])
	if Save.spend(price):
		Save.owned_cars.append(idx)
		Global.selected_car = idx
		Global.remember_selection()
		Sfx.play("buy")
		menu.toast("%s dibeli!" % String(Global.CARS[idx]["name"]), UIKit.C_GOLD)
		menu.refresh_coins()
		_refresh(true)
	else:
		Sfx.play("error")
		menu.toast("Koin tidak cukup", UIKit.C_RED)


func _on_upgrade(i: int) -> void:
	if not Save.has_car(idx):
		return
	var cost: int = Global.upgrade_cost(idx, i)
	if Save.spend(cost):
		var lv: Array = Save.car_upgrades(idx)
		lv[i] = int(lv[i]) + 1
		Save.save_game()
		Sfx.play("buy")
		_refresh(false)
		var vals: Array = _stat_values(idx)
		for b in range(4):
			UIKit.set_stat_bar(_bars[b], float(vals[b]))
	else:
		Sfx.play("error")
		menu.toast("Koin tidak cukup", UIKit.C_RED)


func _on_paint(i: int) -> void:
	Save.set_car_paint(idx, i)
	Sfx.play("select")
	menu.refresh_coins()
	_refresh(false)
