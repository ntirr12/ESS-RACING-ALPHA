extends Control
## Pilih lintasan + mode + opsi balapan, lalu mulai.

const UIKit := preload("res://scripts/ui_kit.gd")
const TrackScript := preload("res://scripts/track.gd")
const PX_TO_M := 0.0556
const LAP_VALUES := [2, 3, 5, 8]


## Pratinjau bentuk lintasan yang digambar dari spline yang sama dengan game.
class TrackPreview extends Control:
	var pts: PackedVector2Array = PackedVector2Array()
	var color: Color = Color(0.1, 0.9, 1.0)
	var _scaled: PackedVector2Array = PackedVector2Array()

	func set_points(p: PackedVector2Array, col: Color) -> void:
		pts = p
		color = col
		_rescale()
		queue_redraw()

	func _notification(what: int) -> void:
		if what == NOTIFICATION_RESIZED:
			_rescale()
			queue_redraw()

	func _rescale() -> void:
		_scaled = PackedVector2Array()
		if pts.size() < 3 or size.x < 10.0:
			return
		var mn: Vector2 = pts[0]
		var mx: Vector2 = pts[0]
		for p in pts:
			mn = Vector2(minf(mn.x, p.x), minf(mn.y, p.y))
			mx = Vector2(maxf(mx.x, p.x), maxf(mx.y, p.y))
		var ext: Vector2 = mx - mn
		var pad: float = 26.0
		var sc: float = minf((size.x - pad * 2.0) / maxf(ext.x, 1.0), (size.y - pad * 2.0) / maxf(ext.y, 1.0))
		var off: Vector2 = size * 0.5 - (mn + ext * 0.5) * sc
		for p in pts:
			_scaled.append(p * sc + off)
		_scaled.append(_scaled[0])

	func _draw() -> void:
		if _scaled.size() < 3:
			return
		draw_polyline(_scaled, Color(0, 0, 0, 0.55), 20.0, true)
		draw_polyline(_scaled, Color(0.28, 0.3, 0.38), 14.0, true)
		draw_polyline(_scaled, Color(color.r, color.g, color.b, 0.9), 3.0, true)
		draw_circle(_scaled[0], 9.0, Color(1, 1, 1))
		draw_circle(_scaled[0], 5.0, Color(0.1, 0.1, 0.12))


var menu = null
var idx: int = 0

var _preview: TrackPreview
var _name: Label
var _desc: Label
var _len: Label
var _rec_lap: Label
var _rec_drift: Label
var _diff_bar: HBoxContainer
var _lock_btn: Button
var _mode_btns: Array = []
var _mode_desc: Label
var _laps_row: HBoxContainer
var _diff_row: HBoxContainer
var _car_lbl: Label
var _start: Button
var _cache: Dictionary = {}


func _ready() -> void:
	var root := VBoxContainer.new()
	add_child(root)
	UIKit.fill(root)

	var head := HBoxContainer.new()
	root.add_child(head)
	head.add_child(UIKit.button("KEMBALI", 26, 0, Vector2(200, 64), func() -> void: menu.go("main")))
	var t := UIKit.label("PILIH LINTASAN", 46, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	head.add_child(menu.make_coin_chip())

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 18)
	root.add_child(body)

	# ---- kiri: kartu lintasan
	var card_row := HBoxContainer.new()
	card_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card_row.size_flags_stretch_ratio = 1.55
	body.add_child(card_row)
	card_row.add_child(UIKit.arrow_button(-1, func() -> void: _step(-1)))
	var card := UIKit.panel(UIKit.C_PANEL, 22, 16)
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card_row.add_child(card)
	card_row.add_child(UIKit.arrow_button(1, func() -> void: _step(1)))
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 6)
	card.add_child(cv)
	_name = UIKit.label("", 40, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 5)
	cv.add_child(_name)
	_preview = TrackPreview.new()
	_preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_preview.custom_minimum_size = Vector2(300, 170)
	cv.add_child(_preview)
	_desc = UIKit.label("", 20, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_CENTER)
	_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_desc.custom_minimum_size = Vector2(300, 52)
	cv.add_child(_desc)
	_diff_bar = UIKit.stat_bar("Kesulitan", 0.3, UIKit.C_PINK, 130.0)
	cv.add_child(_diff_bar)
	var stats := HBoxContainer.new()
	stats.add_theme_constant_override("separation", 14)
	_len = UIKit.label("", 21, UIKit.C_TEXT)
	_rec_lap = UIKit.label("", 21, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	_rec_drift = UIKit.label("", 21, UIKit.C_GREEN, HORIZONTAL_ALIGNMENT_RIGHT)
	for l in [_len, _rec_lap, _rec_drift]:
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		stats.add_child(l)
	cv.add_child(stats)
	_lock_btn = UIKit.button("", 28, 3, Vector2(0, 62), _on_unlock)
	cv.add_child(_lock_btn)

	# ---- kanan: mode & opsi
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 8)
	body.add_child(right)
	right.add_child(UIKit.label("MODE", 22, UIKit.C_PINK))
	for i in range(3):
		var mb := UIKit.button(String(Global.MODE_NAMES[i]), 28, 0, Vector2(0, 62), func() -> void: _set_mode(i))
		right.add_child(mb)
		_mode_btns.append(mb)
	_mode_desc = UIKit.label("", 20, UIKit.C_DIM)
	_mode_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_mode_desc.custom_minimum_size = Vector2(260, 56)
	right.add_child(_mode_desc)

	var lap_opts: Array = ["2 lap", "3 lap", "5 lap", "8 lap"]
	var lap_cur: int = maxi(0, LAP_VALUES.find(Global.laps))
	_laps_row = UIKit.option_row("Jumlah lap", lap_opts, lap_cur, _set_laps)
	right.add_child(_laps_row)
	_diff_row = UIKit.option_row("Lawan", Global.DIFFICULTY_NAMES, Global.difficulty, _set_diff)
	right.add_child(_diff_row)

	var car_row := HBoxContainer.new()
	_car_lbl = UIKit.label("", 24, UIKit.C_TEXT)
	_car_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	car_row.add_child(_car_lbl)
	car_row.add_child(UIKit.button("GANTI", 22, 0, Vector2(130, 54), func() -> void: menu.go("garage")))
	right.add_child(car_row)
	right.add_child(UIKit.spacer(0, true))
	_start = UIKit.button("MULAI", 42, 1, Vector2(0, 92), _on_start)
	right.add_child(_start)

	idx = Global.selected_map
	_refresh()


func on_show() -> void:
	idx = Global.selected_map
	_refresh()


func _step(d: int) -> void:
	idx = (idx + d + Global.MAPS.size()) % Global.MAPS.size()
	_refresh()
	UIKit.pop(_preview)


func _set_laps(i: int) -> void:
	Global.laps = int(LAP_VALUES[i])
	Global.remember_selection()


func _set_diff(i: int) -> void:
	Global.difficulty = i
	Global.remember_selection()


func _set_mode(m: int) -> void:
	Global.selected_mode = m
	Global.remember_selection()
	_refresh()


func _refresh() -> void:
	var m: Dictionary = Global.MAPS[idx]
	var key: String = str(idx)
	var owned: bool = Save.has_map(idx)
	_name.text = String(m["name"]).to_upper()
	_desc.text = String(m["desc"])
	UIKit.set_stat_bar(_diff_bar, float(m["stars"]) / 3.0)

	if not _cache.has(idx):
		_cache[idx] = TrackScript.sample(m["pts"], 90.0)
	var sample: Dictionary = _cache[idx]
	_preview.set_points(sample["pts"], Color(String(m["kerb1"])))
	_len.text = "%.2f km" % (float(sample["length"]) * PX_TO_M / 1000.0)
	var bl: float = float(Save.best_lap.get(key, 0.0))
	_rec_lap.text = "Lap " + (Global.fmt_time(bl) if bl > 0.0 else "--")
	var bd: int = int(Save.best_drift.get(key, 0))
	_rec_drift.text = "Drift " + (Global.fmt_int(bd) if bd > 0 else "--")
	_preview.modulate = Color(1, 1, 1, 1.0 if owned else 0.35)

	if owned:
		_lock_btn.visible = false
	else:
		_lock_btn.visible = true
		_lock_btn.text = "BUKA  " + Global.fmt_int(int(m["price"]))

	# mode
	for i in range(_mode_btns.size()):
		var b: Button = _mode_btns[i]
		if i == Global.selected_mode:
			UIKit.style_button(b, UIKit.C_CYAN)
		else:
			for st in ["normal", "hover", "pressed", "disabled"]:
				b.remove_theme_stylebox_override(st)
			b.remove_theme_color_override("font_color")
			b.remove_theme_color_override("font_hover_color")
			b.remove_theme_color_override("font_pressed_color")
	_mode_desc.text = String(Global.MODE_DESC[Global.selected_mode])
	_laps_row.visible = Global.selected_mode != 2
	_diff_row.visible = Global.selected_mode == 0
	_car_lbl.text = "Mobil: " + String(Global.CARS[Global.selected_car]["name"])
	_start.disabled = not owned
	_start.text = "MULAI" if owned else "TERKUNCI"


func _on_unlock() -> void:
	var price: int = int(Global.MAPS[idx]["price"])
	if Save.spend(price):
		Save.owned_maps.append(idx)
		Save.save_game()
		Sfx.play("buy")
		menu.toast("Lintasan dibuka!", UIKit.C_GOLD)
		_refresh()
	else:
		Sfx.play("error")
		menu.toast("Koin tidak cukup", UIKit.C_RED)


func _on_start() -> void:
	if not Save.has_map(idx):
		return
	Global.selected_map = idx
	Global.remember_selection()
	Global.goto_scene(Global.GAME_SCENE)
