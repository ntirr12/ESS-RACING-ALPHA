extends CanvasLayer
## HUD sesi balapan: kontrol sentuh, speedometer, minimap, skor drift, jeda, hasil.

const UIKit := preload("res://scripts/ui_kit.gd")


# ====================================================================== kontrol sentuh
class TouchLayer extends Control:
	signal pause_pressed
	signal respawn_pressed

	var scheme: int = 0
	var auto_gas: bool = true
	var margins: Vector4 = Vector4(24, 16, 24, 16)
	var nitro_frac: float = 0.0
	var zones: Dictionary = {}          # nama -> {"c": Vector2, "r": float}
	var touches: Dictionary = {}        # index jari -> nama zona
	var joy_finger: int = -1
	var joy_origin: Vector2 = Vector2.ZERO
	var joy_pos: Vector2 = Vector2.ZERO
	var joy_rect: Rect2 = Rect2()
	var font: Font = null

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func layout() -> void:
		var w: float = size.x
		var h: float = size.y
		var ml: float = margins.x
		var mt: float = margins.y
		var mr: float = margins.z
		var mb: float = margins.w
		zones.clear()
		if scheme == 0:
			zones["left"] = {"c": Vector2(ml + 105, h - mb - 105), "r": 98.0}
			zones["right"] = {"c": Vector2(ml + 330, h - mb - 105), "r": 98.0}
		else:
			joy_rect = Rect2(Vector2(0, h * 0.28), Vector2(w * 0.45, h * 0.72))
		if auto_gas:
			zones["drift"] = {"c": Vector2(w - mr - 135, h - mb - 130), "r": 104.0}
			zones["nitro"] = {"c": Vector2(w - mr - 95, h - mb - 315), "r": 68.0}
			zones["brake"] = {"c": Vector2(w - mr - 335, h - mb - 90), "r": 66.0}
		else:
			zones["gas"] = {"c": Vector2(w - mr - 130, h - mb - 130), "r": 108.0}
			zones["drift"] = {"c": Vector2(w - mr - 340, h - mb - 90), "r": 76.0}
			zones["brake"] = {"c": Vector2(w - mr - 320, h - mb - 245), "r": 62.0}
			zones["nitro"] = {"c": Vector2(w - mr - 95, h - mb - 335), "r": 66.0}
		zones["pause"] = {"c": Vector2(w - mr - 40, mt + 44), "r": 36.0}
		zones["respawn"] = {"c": Vector2(w - mr - 124, mt + 44), "r": 32.0}
		queue_redraw()

	func release_all() -> void:
		touches.clear()
		joy_finger = -1
		queue_redraw()

	func _hit(pos: Vector2) -> String:
		var best: String = ""
		var best_ratio: float = 1.18
		for k in zones.keys():
			var z: Dictionary = zones[k]
			var ratio: float = pos.distance_to(z["c"]) / float(z["r"])
			if ratio < best_ratio:
				best_ratio = ratio
				best = k
		if best == "" and scheme == 1 and joy_rect.has_point(pos):
			return "joy"
		return best

	func _input(event: InputEvent) -> void:
		if get_tree().paused:
			return
		if event is InputEventScreenTouch:
			var t := event as InputEventScreenTouch
			if t.pressed:
				_down(t.index, t.position)
			else:
				_up(t.index)
		elif event is InputEventScreenDrag:
			var d := event as InputEventScreenDrag
			_move(d.index, d.position)

	func _down(i: int, pos: Vector2) -> void:
		var z: String = _hit(pos)
		if z == "joy":
			joy_finger = i
			joy_origin = pos
			joy_pos = pos
		elif z == "pause":
			pause_pressed.emit()
		elif z == "respawn":
			respawn_pressed.emit()
		touches[i] = z
		queue_redraw()

	func _up(i: int) -> void:
		if i == joy_finger:
			joy_finger = -1
		touches.erase(i)
		queue_redraw()

	func _move(i: int, pos: Vector2) -> void:
		if not touches.has(i):
			return
		var owner_zone: String = touches[i]
		if owner_zone == "joy":
			var v: Vector2 = pos - joy_origin
			if v.length() > 110.0:
				joy_origin = pos - v.normalized() * 110.0
			joy_pos = pos
		elif owner_zone != "pause" and owner_zone != "respawn":
			var z: String = _hit(pos)
			if z == "pause" or z == "respawn" or z == "joy":
				z = ""
			touches[i] = z
		queue_redraw()

	func get_state(car_rot: float) -> Dictionary:
		var held: Dictionary = {}
		for v in touches.values():
			held[v] = true
		var steer: float = 0.0
		if scheme == 0:
			if held.has("right"):
				steer += 1.0
			if held.has("left"):
				steer -= 1.0
		elif joy_finger >= 0 and touches.has(joy_finger):
			var v2: Vector2 = joy_pos - joy_origin
			if v2.length() > 16.0:
				var diff: float = wrapf(v2.angle() - car_rot, -PI, PI)
				steer = clampf(diff * 2.4, -1.0, 1.0)
		var gas: float = 1.0 if auto_gas else (1.0 if held.has("gas") else 0.0)
		return {"steer": steer, "gas": gas, "brake": held.has("brake"), "hb": held.has("drift"), "nitro": held.has("nitro")}

	func _is_down(name_: String) -> bool:
		for v in touches.values():
			if v == name_:
				return true
		return false

	func _draw() -> void:
		if font == null:
			font = ThemeDB.fallback_font
		for k in zones.keys():
			var z: Dictionary = zones[k]
			var c: Vector2 = z["c"]
			var r: float = float(z["r"])
			var down: bool = _is_down(k)
			var ring: Color = Color(1, 1, 1, 0.5)
			var fill: Color = Color(1, 1, 1, 0.34 if down else 0.12)
			match k:
				"drift":
					ring = Color(1.0, 0.25, 0.6, 0.85)
					fill = Color(1.0, 0.2, 0.55, 0.42 if down else 0.16)
				"nitro":
					ring = Color(0.2, 0.9, 1.0, 0.9)
					fill = Color(0.1, 0.8, 1.0, 0.42 if down else 0.14)
				"gas":
					ring = Color(0.3, 1.0, 0.5, 0.85)
					fill = Color(0.2, 1.0, 0.45, 0.4 if down else 0.14)
				"brake":
					ring = Color(1.0, 0.45, 0.35, 0.8)
					fill = Color(1.0, 0.3, 0.2, 0.4 if down else 0.13)
				"pause", "respawn":
					fill = Color(0, 0, 0, 0.35 if not down else 0.6)
			draw_circle(c, r, fill)
			draw_arc(c, r, 0.0, TAU, 40, ring, 3.0, true)
			match k:
				"left":
					_arrow(c, -1, r)
				"right":
					_arrow(c, 1, r)
				"drift":
					_text(c, "DRIFT", 30)
				"gas":
					_text(c, "GAS", 34)
				"brake":
					_text(c, "REM", 24)
				"nitro":
					_bolt(c, r)
					if nitro_frac > 0.01:
						draw_arc(c, r + 7.0, -PI * 0.5, -PI * 0.5 + TAU * nitro_frac, 40, Color(0.3, 0.95, 1.0, 0.95) if nitro_frac < 0.999 else Color(1.0, 0.85, 0.3, 1.0), 6.0, true)
				"pause":
					draw_rect(Rect2(c + Vector2(-11, -13), Vector2(8, 26)), Color.WHITE)
					draw_rect(Rect2(c + Vector2(3, -13), Vector2(8, 26)), Color.WHITE)
				"respawn":
					draw_arc(c, 13.0, -PI * 0.2, PI * 1.3, 24, Color.WHITE, 4.0, true)
					var tip: Vector2 = c + Vector2.from_angle(-PI * 0.2) * 13.0
					draw_colored_polygon(PackedVector2Array([tip + Vector2(-7, -6), tip + Vector2(8, -2), tip + Vector2(-2, 9)]), Color.WHITE)
		if scheme == 1:
			if joy_finger >= 0 and touches.has(joy_finger):
				draw_circle(joy_origin, 100.0, Color(1, 1, 1, 0.1))
				draw_arc(joy_origin, 100.0, 0.0, TAU, 40, Color(1, 1, 1, 0.45), 3.0, true)
				var off: Vector2 = (joy_pos - joy_origin).limit_length(100.0)
				draw_circle(joy_origin + off, 44.0, Color(0.2, 0.9, 1.0, 0.55))
			else:
				var hc := Vector2(margins.x + 170, size.y - margins.w - 150)
				draw_arc(hc, 90.0, 0.0, TAU, 40, Color(1, 1, 1, 0.25), 3.0, true)
				draw_circle(hc, 38.0, Color(1, 1, 1, 0.12))

	func _text(c: Vector2, txt: String, fs: int) -> void:
		var wdt: float = 200.0
		draw_string(font, Vector2(c.x - wdt * 0.5, c.y + fs * 0.35), txt, HORIZONTAL_ALIGNMENT_CENTER, wdt, fs, Color(1, 1, 1, 0.95))

	func _arrow(c: Vector2, dir: int, r: float) -> void:
		var s: float = r * 0.38
		var pts := PackedVector2Array()
		if dir > 0:
			pts = PackedVector2Array([c + Vector2(-s * 0.6, -s), c + Vector2(s * 0.9, 0), c + Vector2(-s * 0.6, s)])
		else:
			pts = PackedVector2Array([c + Vector2(s * 0.6, -s), c + Vector2(-s * 0.9, 0), c + Vector2(s * 0.6, s)])
		draw_colored_polygon(pts, Color(1, 1, 1, 0.92))

	func _bolt(c: Vector2, r: float) -> void:
		var s: float = r * 0.5
		var pts := PackedVector2Array([c + Vector2(s * 0.15, -s), c + Vector2(-s * 0.6, s * 0.15), c + Vector2(-s * 0.05, s * 0.15), c + Vector2(-s * 0.2, s), c + Vector2(s * 0.6, -s * 0.2), c + Vector2(s * 0.05, -s * 0.2)])
		draw_colored_polygon(pts, Color(0.75, 0.97, 1.0, 0.95))


# ====================================================================== minimap
class MiniMap extends Control:
	var pts: PackedVector2Array = PackedVector2Array()
	var game = null
	var _origin: Vector2 = Vector2.ZERO
	var _scale: float = 1.0

	func setup(track, g) -> void:
		game = g
		custom_minimum_size = Vector2(150, 150)
		size = Vector2(150, 150)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		var mn: Vector2 = track.pts[0]
		var mx: Vector2 = track.pts[0]
		for p in track.pts:
			mn = Vector2(minf(mn.x, p.x), minf(mn.y, p.y))
			mx = Vector2(maxf(mx.x, p.x), maxf(mx.y, p.y))
		var ext: Vector2 = mx - mn
		_scale = minf(118.0 / maxf(ext.x, 1.0), 118.0 / maxf(ext.y, 1.0))
		_origin = Vector2(75, 75) - (mn + ext * 0.5) * _scale
		pts = PackedVector2Array()
		var n: int = track.pts.size()
		for i in range(0, n, 3):
			pts.append(track.pts[i] * _scale + _origin)
		pts.append(pts[0])

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.38), true)
		draw_rect(Rect2(Vector2.ZERO, size), Color(1, 1, 1, 0.18), false, 2.0)
		if pts.size() > 2:
			draw_polyline(pts, Color(0, 0, 0, 0.8), 8.0, true)
			draw_polyline(pts, Color(0.85, 0.9, 1.0, 0.9), 4.0, true)
		if game == null:
			return
		for c in game.cars:
			var p: Vector2 = c.global_position * _scale + _origin
			if c == game.player:
				draw_circle(p, 7.0, Color(0, 0, 0, 0.8))
				draw_circle(p, 5.0, Color(0.1, 0.95, 1.0))
			else:
				draw_circle(p, 5.0, Color(0, 0, 0, 0.8))
				draw_circle(p, 3.5, Color(1.0, 0.25, 0.6))


# ====================================================================== speedometer
class Dash extends Control:
	var kmh: float = 0.0
	var kmh_max: float = 240.0
	var nitro: float = 0.0
	var boost: bool = false
	var font: Font = null

	func _init() -> void:
		custom_minimum_size = Vector2(250, 220)
		size = Vector2(250, 220)
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		if font == null:
			font = ThemeDB.fallback_font
		var c := Vector2(125, 112)
		var a0: float = deg_to_rad(150.0)
		var sweep: float = deg_to_rad(240.0)
		var frac: float = clampf(kmh / kmh_max, 0.0, 1.0)
		draw_arc(c, 92.0, a0, a0 + sweep, 56, Color(0, 0, 0, 0.45), 20.0, true)
		draw_arc(c, 92.0, a0, a0 + sweep, 56, Color(1, 1, 1, 0.14), 14.0, true)
		if frac > 0.005:
			var col: Color = Color(0.1, 0.9, 1.0).lerp(Color(1.0, 0.2, 0.55), frac)
			if boost:
				col = Color(1.0, 0.82, 0.25)
			draw_arc(c, 92.0, a0, a0 + sweep * frac, 56, col, 14.0, true)
		draw_string(font, Vector2(c.x - 100, c.y + 18), str(int(kmh)), HORIZONTAL_ALIGNMENT_CENTER, 200, 66, Color(1, 1, 1, 0.97))
		draw_string(font, Vector2(c.x - 100, c.y + 46), "KM/H", HORIZONTAL_ALIGNMENT_CENTER, 200, 22, Color(0.7, 0.78, 0.9, 0.9))
		# batang nitro
		var bar := Rect2(Vector2(35, 204), Vector2(180, 12))
		draw_rect(bar, Color(0, 0, 0, 0.5), true)
		var fill_col: Color = Color(1.0, 0.82, 0.25) if boost else Color(0.15, 0.85, 1.0)
		draw_rect(Rect2(bar.position, Vector2(bar.size.x * clampf(nitro, 0.0, 1.0), bar.size.y)), fill_col, true)
		draw_rect(bar, Color(1, 1, 1, 0.35), false, 2.0)


# ====================================================================== HUD utama
var game = null
var root: Control
var touch: TouchLayer
var minimap: MiniMap
var dash: Dash

var _info_lap: Label
var _info_time: Label
var _info_best: Label
var _info_pos: Label
var _chain_box: VBoxContainer
var _chain_lbl: Label
var _mult_lbl: Label
var _flash_lbl: Label
var _msg_lbl: Label
var _wrong_lbl: Label
var _hint_lbl: Label
var _fps_lbl: Label
var _vig_speed: TextureRect
var _vig_fx: TextureRect
var _info_panel: PanelContainer

var _flash_tw: Tween = null
var _msg_tw: Tween = null
var _hint_tw: Tween = null
var _vig_tw: Tween = null
var _map_t: float = 0.0
var _cache: Dictionary = {}
var _pause_layer: CanvasLayer = null
var _result_layer: CanvasLayer = null
var _tutorial_stage: int = 0


func setup(g) -> void:
	game = g
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.theme = UIKit.make_theme()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	UIKit.fill(root)

	_vig_speed = _make_vignette(Color(0.02, 0.02, 0.06))
	_vig_fx = _make_vignette(Color(1, 0.1, 0.1))
	_vig_speed.modulate.a = 0.0
	_vig_fx.modulate.a = 0.0

	touch = TouchLayer.new()
	touch.scheme = int(Save.opt["scheme"])
	touch.auto_gas = bool(Save.opt["auto_gas"])
	root.add_child(touch)
	UIKit.fill(touch)
	touch.pause_pressed.connect(pause)
	touch.respawn_pressed.connect(func() -> void: game.respawn_player())

	_build_info()
	_build_chain()
	_build_center()

	minimap = MiniMap.new()
	root.add_child(minimap)
	minimap.setup(game.track, game)

	dash = Dash.new()
	root.add_child(dash)

	_fps_lbl = UIKit.label("", 18, Color(1, 1, 1, 0.6), HORIZONTAL_ALIGNMENT_CENTER)
	_fps_lbl.visible = bool(Save.opt["show_fps"])
	root.add_child(_fps_lbl)

	root.resized.connect(_layout)
	get_viewport().size_changed.connect(_layout)
	_layout.call_deferred()


func _make_vignette(col: Color) -> TextureRect:
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 0), Color(1, 1, 1, 1)])
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	var tr := TextureRect.new()
	tr.texture = gt
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tr.modulate = col
	root.add_child(tr)
	UIKit.fill(tr)
	return tr


func _build_info() -> void:
	_info_panel = UIKit.panel(Color(0, 0, 0, 0.36), 14, 12)
	root.add_child(_info_panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	_info_panel.add_child(vb)
	_info_lap = UIKit.label("", 30, UIKit.C_TEXT, HORIZONTAL_ALIGNMENT_LEFT, 4)
	_info_time = UIKit.label("", 30, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_LEFT, 4)
	_info_best = UIKit.label("", 20, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, 3)
	_info_pos = UIKit.label("", 30, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_LEFT, 4)
	vb.add_child(_info_pos)
	vb.add_child(_info_lap)
	vb.add_child(_info_time)
	vb.add_child(_info_best)
	_info_pos.visible = int(game.mode) == 0


func _build_chain() -> void:
	_chain_box = VBoxContainer.new()
	_chain_box.add_theme_constant_override("separation", 0)
	_chain_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_chain_box)
	_chain_lbl = UIKit.label("", 54, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 8)
	_mult_lbl = UIKit.label("", 28, UIKit.C_PINK, HORIZONTAL_ALIGNMENT_CENTER, 6)
	_chain_box.add_child(_chain_lbl)
	_chain_box.add_child(_mult_lbl)
	_chain_box.visible = false
	_flash_lbl = UIKit.label("", 40, UIKit.C_GREEN, HORIZONTAL_ALIGNMENT_CENTER, 8)
	_flash_lbl.modulate.a = 0.0
	root.add_child(_flash_lbl)


func _build_center() -> void:
	_msg_lbl = UIKit.label("", 130, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 14)
	_msg_lbl.modulate.a = 0.0
	root.add_child(_msg_lbl)
	_wrong_lbl = UIKit.label("ARAH SALAH!", 54, UIKit.C_RED, HORIZONTAL_ALIGNMENT_CENTER, 10)
	_wrong_lbl.visible = false
	root.add_child(_wrong_lbl)
	_hint_lbl = UIKit.label("", 28, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 6)
	_hint_lbl.modulate.a = 0.0
	root.add_child(_hint_lbl)


func _safe_margins() -> Vector4:
	var m := Vector4(26, 16, 26, 18)
	if OS.has_feature("mobile"):
		var safe: Rect2i = DisplayServer.get_display_safe_area()
		var win: Vector2i = DisplayServer.window_get_size()
		if win.x > 0 and win.y > 0 and safe.size.x > 0:
			var sx: float = root.size.x / float(win.x)
			var sy: float = root.size.y / float(win.y)
			m.x += maxf(0.0, float(safe.position.x)) * sx
			m.z += maxf(0.0, float(win.x - safe.position.x - safe.size.x)) * sx
			m.y += maxf(0.0, float(safe.position.y)) * sy
			m.w += maxf(0.0, float(win.y - safe.position.y - safe.size.y)) * sy
	return m


func _layout() -> void:
	if root == null:
		return
	var w: float = root.size.x
	var h: float = root.size.y
	if w < 10.0:
		return
	var m: Vector4 = _safe_margins()
	touch.margins = m
	touch.layout()
	_info_panel.position = Vector2(m.x, m.y)
	minimap.position = Vector2(w - m.z - 124.0 - 32.0 - 40.0 - 150.0, m.y)
	dash.position = Vector2(w * 0.5 - 125.0, h - m.w - 225.0)
	_chain_box.position = Vector2(w * 0.5 - 250.0, m.y + 4.0)
	_chain_box.size = Vector2(500.0, 100.0)
	_flash_lbl.position = Vector2(w * 0.5 - 300.0, m.y + 118.0)
	_flash_lbl.size = Vector2(600.0, 56.0)
	_msg_lbl.position = Vector2(w * 0.5 - 400.0, h * 0.18)
	_msg_lbl.size = Vector2(800.0, 170.0)
	_msg_lbl.pivot_offset = Vector2(400.0, 85.0)
	_wrong_lbl.position = Vector2(w * 0.5 - 300.0, h * 0.34)
	_wrong_lbl.size = Vector2(600.0, 70.0)
	_hint_lbl.position = Vector2(w * 0.5 - 450.0, h * 0.52)
	_hint_lbl.size = Vector2(900.0, 40.0)
	_fps_lbl.position = Vector2(w * 0.5 - 100.0, 2.0)
	_fps_lbl.size = Vector2(200.0, 24.0)


# ------------------------------------------------------------------ API untuk game
func get_input(car_rot: float) -> Dictionary:
	return touch.get_state(car_rot)


func countdown(txt: String) -> void:
	_msg_lbl.text = txt
	_msg_lbl.modulate = Color(1, 1, 1, 1)
	_msg_lbl.add_theme_color_override("font_color", UIKit.C_GREEN if txt == "GO!" else Color.WHITE)
	_msg_lbl.scale = Vector2(1.5, 1.5)
	if _msg_tw != null:
		_msg_tw.kill()
	_msg_tw = create_tween()
	_msg_tw.tween_property(_msg_lbl, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_msg_tw.tween_interval(0.45)
	_msg_tw.tween_property(_msg_lbl, "modulate:a", 0.0, 0.3)
	if txt == "GO!":
		_start_tutorial()


func flash(txt: String, col: Color) -> void:
	_flash_lbl.text = txt
	_flash_lbl.add_theme_color_override("font_color", col)
	_flash_lbl.modulate.a = 1.0
	_flash_lbl.pivot_offset = _flash_lbl.size * 0.5
	_flash_lbl.scale = Vector2(1.3, 1.3)
	if _flash_tw != null:
		_flash_tw.kill()
	_flash_tw = create_tween()
	_flash_tw.tween_property(_flash_lbl, "scale", Vector2.ONE, 0.18)
	_flash_tw.tween_interval(0.9)
	_flash_tw.tween_property(_flash_lbl, "modulate:a", 0.0, 0.4)


func hint(txt: String, dur: float = 3.0) -> void:
	_hint_lbl.text = txt
	_hint_lbl.modulate.a = 1.0
	if _hint_tw != null:
		_hint_tw.kill()
	_hint_tw = create_tween()
	_hint_tw.tween_interval(dur)
	_hint_tw.tween_property(_hint_lbl, "modulate:a", 0.0, 0.5)


func on_lap(wraps: int, lap_time: float, is_best: bool) -> void:
	Sfx.play("lap", -3.0)
	var txt: String = "LAP %d  %s" % [wraps, Global.fmt_time(lap_time)]
	flash(txt + ("  TERBAIK!" if is_best else ""), UIKit.C_GOLD if is_best else UIKit.C_CYAN)


func set_wrong_way(on: bool) -> void:
	_wrong_lbl.visible = on and int(Time.get_ticks_msec() / 300) % 2 == 0


func punch_vignette() -> void:
	_vig_fx.modulate = Color(1, 0.1, 0.1, 0.55)
	if _vig_tw != null:
		_vig_tw.kill()
	_vig_tw = create_tween()
	_vig_tw.tween_property(_vig_fx, "modulate:a", 0.0, 0.45)


func _start_tutorial() -> void:
	if Save.seen_tutorial:
		return
	Save.seen_tutorial = true
	Save.save_game()
	hint("Tahan DRIFT sambil belok untuk melakukan drift!", 4.0)
	get_tree().create_timer(4.6).timeout.connect(func() -> void:
		hint("Drift panjang mengisi NITRO. Tekan tombol petir untuk boost!", 4.0))


func _set_text(lbl: Label, key: String, txt: String) -> void:
	if _cache.get(key, "") != txt:
		_cache[key] = txt
		lbl.text = txt


# ------------------------------------------------------------------ update tiap frame
func _process(delta: float) -> void:
	if game == null or game.player == null or get_tree().paused:
		return
	var p = game.player
	dash.kmh = p.spd * 0.2
	dash.kmh_max = float(p.stats["max"]) * 0.2 * 1.25
	dash.nitro = p.nitro / 100.0
	dash.boost = p.boosting
	dash.queue_redraw()
	var nf: float = p.nitro / 100.0
	if absf(nf - touch.nitro_frac) > 0.008:
		touch.nitro_frac = nf
		touch.queue_redraw()

	var mode: int = int(game.mode)
	if mode == 2:
		_set_text(_info_lap, "lap", "SKOR  %s" % Global.fmt_int(p.drift_total))
		var left: int = int(ceil(game.drift_left))
		_set_text(_info_time, "time", "%d:%02d" % [left / 60, left % 60])
		_set_text(_info_best, "best", "Target emas %s" % Global.fmt_int(int(Global.DRIFT_MEDALS[2])))
	else:
		var lapn: int = clampi(p.wraps + 1, 1, int(game.laps))
		_set_text(_info_lap, "lap", "LAP %d / %d" % [lapn, game.laps])
		_set_text(_info_time, "time", Global.fmt_time(game.race_time))
		var bl: float = p.best_lap
		_set_text(_info_best, "best", "Terbaik " + (Global.fmt_time(bl) if not is_inf(bl) else "--:--.--"))
		if mode == 0:
			_set_text(_info_pos, "pos", "P%d / %d" % [game.player_rank, game.cars.size()])

	# rantai drift
	var cd: int = p.chain_display()
	if p.chain_points > 0.0:
		_chain_box.visible = true
		_set_text(_chain_lbl, "chain", Global.fmt_int(cd))
		_set_text(_mult_lbl, "mult", "DRIFT  x%d" % p.chain_mult)
		var fading: bool = p.grace < 0.99 and not p.drifting
		_chain_lbl.modulate = Color(1, 1, 1, 0.55) if fading else Color(1, 1, 1, 1)
	else:
		_chain_box.visible = false

	# vinyet kecepatan & nitro
	var ratio: float = clampf(p.spd / float(p.stats["max"]), 0.0, 1.3)
	var target_a: float = clampf((ratio - 0.55) * 0.9, 0.0, 0.45)
	if p.boosting:
		_vig_fx.modulate = Color(0.2, 0.85, 1.0, 0.35)
	elif _vig_tw == null or not _vig_tw.is_running():
		_vig_fx.modulate.a = lerpf(_vig_fx.modulate.a, 0.0, 1.0 - exp(-8.0 * delta))
	_vig_speed.modulate.a = lerpf(_vig_speed.modulate.a, target_a, 1.0 - exp(-4.0 * delta))

	_map_t -= delta
	if _map_t <= 0.0:
		_map_t = 0.066
		minimap.queue_redraw()
		if _fps_lbl.visible:
			_fps_lbl.text = "%d FPS" % Engine.get_frames_per_second()


func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo and (k.keycode == KEY_ESCAPE or k.keycode == KEY_P):
			toggle_pause()
		elif k.pressed and not k.echo and k.keycode == KEY_R and not get_tree().paused:
			game.respawn_player()


# ------------------------------------------------------------------ jeda
func toggle_pause() -> void:
	if _result_layer != null:
		return
	if get_tree().paused:
		resume()
	else:
		pause()


func pause() -> void:
	if get_tree().paused or _result_layer != null or int(game.state) == 0:
		return
	touch.release_all()
	get_tree().paused = true
	Sfx.duck_music(true)
	_pause_layer = CanvasLayer.new()
	_pause_layer.layer = 30
	add_child(_pause_layer)
	var ov := Control.new()
	ov.theme = UIKit.make_theme()
	_pause_layer.add_child(ov)
	UIKit.fill(ov)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.62)
	ov.add_child(dim)
	UIKit.fill(dim)
	var center := CenterContainer.new()
	ov.add_child(center)
	UIKit.fill(center)
	var panel := UIKit.panel(UIKit.C_PANEL, 24, 28)
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(440, 0)
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	vb.add_child(UIKit.label("JEDA", 56, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER))
	vb.add_child(UIKit.button("LANJUT", 32, 1, Vector2(0, 68), resume))
	vb.add_child(UIKit.button("ULANGI", 28, 0, Vector2(0, 68), func() -> void: game.restart()))
	var music_btn := UIKit.button("", 26, 0, Vector2(0, 68), Callable())
	var sfx_btn := UIKit.button("", 26, 0, Vector2(0, 68), Callable())
	var refresh := func() -> void:
		music_btn.text = "MUSIK: " + ("NYALA" if int(Save.opt["music"]) > 0 else "MATI")
		sfx_btn.text = "EFEK SUARA: " + ("NYALA" if int(Save.opt["sfx"]) > 0 else "MATI")
	refresh.call()
	music_btn.pressed.connect(func() -> void:
		Save.set_opt("music", 0 if int(Save.opt["music"]) > 0 else 7)
		Sfx.apply_volumes()
		refresh.call())
	sfx_btn.pressed.connect(func() -> void:
		Save.set_opt("sfx", 0 if int(Save.opt["sfx"]) > 0 else 9)
		Sfx.apply_volumes()
		refresh.call())
	vb.add_child(music_btn)
	vb.add_child(sfx_btn)
	vb.add_child(UIKit.button("KELUAR KE MENU", 26, 2, Vector2(0, 68), func() -> void: game.to_menu()))
	ov.modulate.a = 0.0
	var tw := ov.create_tween()
	tw.tween_property(ov, "modulate:a", 1.0, 0.15)


func resume() -> void:
	if _pause_layer != null:
		_pause_layer.queue_free()
		_pause_layer = null
	touch.release_all()
	get_tree().paused = false
	Sfx.duck_music(false)


# ------------------------------------------------------------------ hasil
func show_results(res: Dictionary) -> void:
	touch.release_all()
	touch.visible = false
	await get_tree().create_timer(1.0).timeout
	if not is_inside_tree():
		return
	_result_layer = CanvasLayer.new()
	_result_layer.layer = 30
	add_child(_result_layer)
	var ov := Control.new()
	ov.theme = UIKit.make_theme()
	_result_layer.add_child(ov)
	UIKit.fill(ov)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	ov.add_child(dim)
	UIKit.fill(dim)
	var center := CenterContainer.new()
	ov.add_child(center)
	UIKit.fill(center)
	var panel := UIKit.panel(UIKit.C_PANEL, 26, 28)
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(620, 0)
	vb.add_theme_constant_override("separation", 8)
	panel.add_child(vb)

	var mode: int = int(res["mode"])
	var medal: int = int(res["medal"])
	var title: String = "FINISH!"
	var sub: String = ""
	var sub_col: Color = UIKit.C_GOLD
	if mode == 0:
		var pl: int = int(res["place"])
		sub = "JUARA %d" % pl if pl == 1 else "POSISI %d" % pl
		sub_col = UIKit.C_GOLD if pl == 1 else (UIKit.C_CYAN if pl <= 2 else UIKit.C_DIM)
	elif mode == 1:
		sub = "MEDALI " + String(Global.MEDAL_NAMES[medal]) if medal > 0 else "BELUM ADA MEDALI"
	else:
		title = "WAKTU HABIS"
		sub = "MEDALI " + String(Global.MEDAL_NAMES[medal]) if medal > 0 else "BELUM ADA MEDALI"
	vb.add_child(UIKit.label(title, 54, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER))
	var medal_cols: Array = [UIKit.C_DIM, Color(0.85, 0.55, 0.3), Color(0.82, 0.88, 0.95), UIKit.C_GOLD]
	if mode != 0:
		sub_col = medal_cols[medal]
	vb.add_child(UIKit.label(sub, 38, sub_col, HORIZONTAL_ALIGNMENT_CENTER))
	if bool(res["record"]):
		vb.add_child(UIKit.label("REKOR BARU!", 28, UIKit.C_GREEN, HORIZONTAL_ALIGNMENT_CENTER))
	vb.add_child(UIKit.spacer(6))

	if mode == 2:
		vb.add_child(_row("Skor drift", Global.fmt_int(int(res["drift"])), true))
		vb.add_child(_row("Rantai terbaik", Global.fmt_int(int(res["best_chain"]))))
	else:
		if mode == 0:
			vb.add_child(_row("Posisi", "%d / %d" % [int(res["place"]), game.cars.size()]))
		vb.add_child(_row("Waktu total", Global.fmt_time(float(res["time"]))))
		vb.add_child(_row("Lap terbaik", Global.fmt_time(float(res["best_lap"])), mode == 1))
		vb.add_child(_row("Skor drift", Global.fmt_int(int(res["drift"]))))
	vb.add_child(UIKit.spacer(6))

	var coin_row := HBoxContainer.new()
	coin_row.alignment = BoxContainer.ALIGNMENT_CENTER
	coin_row.add_child(UIKit.CoinIcon.new())
	var coin_lbl := UIKit.label("+0", 40, UIKit.C_GOLD)
	coin_row.add_child(coin_lbl)
	vb.add_child(coin_row)
	vb.add_child(UIKit.spacer(6))
	var btns := HBoxContainer.new()
	btns.add_theme_constant_override("separation", 14)
	var b1 := UIKit.button("ULANGI", 30, 1, Vector2(0, 68), func() -> void: game.restart())
	var b2 := UIKit.button("MENU", 30, 0, Vector2(0, 68), func() -> void: game.to_menu())
	b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btns.add_child(b1)
	btns.add_child(b2)
	vb.add_child(btns)

	ov.modulate.a = 0.0
	var tw := ov.create_tween()
	tw.tween_property(ov, "modulate:a", 1.0, 0.25)
	var coins: int = int(res["coins"])
	var tw2 := create_tween()
	tw2.tween_interval(0.35)
	tw2.tween_method(func(v: float) -> void: coin_lbl.text = "+" + Global.fmt_int(int(v)), 0.0, float(coins), 1.1).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


func _row(title: String, value: String, highlight: bool = false) -> HBoxContainer:
	var r := HBoxContainer.new()
	var a := UIKit.label(title, 26, UIKit.C_DIM)
	a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var b := UIKit.label(value, 30 if highlight else 26, UIKit.C_GOLD if highlight else UIKit.C_TEXT, HORIZONTAL_ALIGNMENT_RIGHT)
	r.add_child(a)
	r.add_child(b)
	return r
