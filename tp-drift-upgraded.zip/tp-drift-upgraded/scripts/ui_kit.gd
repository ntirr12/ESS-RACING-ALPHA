extends RefCounted
## Kumpulan helper UI (tema, tombol, label, ikon) — semua dibuat lewat kode.

const C_BG := Color(0.043, 0.059, 0.102, 1.0)
const C_PANEL := Color(0.055, 0.075, 0.133, 0.93)
const C_PANEL2 := Color(0.09, 0.12, 0.2, 0.95)
const C_CYAN := Color(0.098, 0.902, 1.0, 1.0)
const C_PINK := Color(1.0, 0.176, 0.584, 1.0)
const C_GOLD := Color(1.0, 0.76, 0.2, 1.0)
const C_GREEN := Color(0.24, 1.0, 0.54, 1.0)
const C_RED := Color(1.0, 0.3, 0.3, 1.0)
const C_TEXT := Color(0.91, 0.94, 1.0, 1.0)
const C_DIM := Color(0.56, 0.62, 0.74, 1.0)

static var _bold: FontVariation = null
static var _theme: Theme = null


static func bold_font() -> Font:
	if _bold == null:
		_bold = FontVariation.new()
		_bold.base_font = ThemeDB.fallback_font
		_bold.variation_embolden = 0.65
	return _bold


static func sb(bg: Color, radius: int = 14, border: Color = Color(0, 0, 0, 0), bw: int = 0, pad: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	if bw > 0:
		s.border_color = border
		s.set_border_width_all(bw)
	if pad > 0:
		s.set_content_margin_all(pad)
	return s


static func make_theme() -> Theme:
	if _theme != null:
		return _theme
	var t := Theme.new()
	t.default_font = bold_font()
	t.default_font_size = 26
	t.set_stylebox("normal", "Button", sb(Color(0.1, 0.14, 0.24, 0.96), 16, Color(0.4, 0.55, 0.85, 0.35), 2, 14))
	t.set_stylebox("hover", "Button", sb(Color(0.14, 0.2, 0.34, 0.98), 16, Color(0.4, 0.8, 1.0, 0.6), 2, 14))
	t.set_stylebox("pressed", "Button", sb(Color(0.07, 0.1, 0.18, 1.0), 16, C_CYAN, 3, 14))
	t.set_stylebox("disabled", "Button", sb(Color(0.08, 0.1, 0.16, 0.7), 16, Color(0.3, 0.35, 0.45, 0.25), 2, 14))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", C_TEXT)
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_pressed_color", "Button", C_CYAN)
	t.set_color("font_disabled_color", "Button", Color(0.5, 0.55, 0.65, 0.7))
	t.set_font_size("font_size", "Button", 28)
	t.set_stylebox("panel", "PanelContainer", sb(C_PANEL, 20, Color(1, 1, 1, 0.08), 2, 18))
	t.set_color("font_color", "Label", C_TEXT)
	t.set_stylebox("fill", "ProgressBar", sb(C_CYAN, 6))
	t.set_stylebox("background", "ProgressBar", sb(Color(1, 1, 1, 0.09), 6))
	t.set_constant("separation", "VBoxContainer", 10)
	t.set_constant("separation", "HBoxContainer", 12)
	_theme = t
	return t


static func label(text: String, size: int = 24, color: Color = C_TEXT, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, outline: int = 0) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if outline > 0:
		l.add_theme_constant_override("outline_size", outline)
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


## kind: 0 = normal, 1 = utama (cyan), 2 = bahaya (merah), 3 = emas
static func button(text: String, font_size: int = 28, kind: int = 0, min_size: Vector2 = Vector2(0, 68), cb: Callable = Callable()) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size)
	if kind > 0:
		var col: Color = C_CYAN
		if kind == 2:
			col = C_RED
		elif kind == 3:
			col = C_GOLD
		style_button(b, col)
	b.pressed.connect(_click_sound)
	if cb.is_valid():
		b.pressed.connect(cb)
	b.resized.connect(func() -> void: b.pivot_offset = b.size * 0.5)
	b.button_down.connect(func() -> void: _tween_scale(b, 0.95))
	b.button_up.connect(func() -> void: _tween_scale(b, 1.0))
	return b


static func _click_sound() -> void:
	Sfx.play("click")


static func _tween_scale(n: Control, s: float) -> void:
	if not n.is_inside_tree():
		return
	var tw := n.create_tween()
	tw.tween_property(n, "scale", Vector2(s, s), 0.08)


static func style_button(b: Button, col: Color) -> void:
	b.add_theme_stylebox_override("normal", sb(Color(col.r * 0.22, col.g * 0.22, col.b * 0.22, 0.97), 16, col, 3, 14))
	b.add_theme_stylebox_override("hover", sb(Color(col.r * 0.32, col.g * 0.32, col.b * 0.32, 1.0), 16, col, 3, 14))
	b.add_theme_stylebox_override("pressed", sb(Color(col.r * 0.5, col.g * 0.5, col.b * 0.5, 1.0), 16, Color.WHITE, 3, 14))
	b.add_theme_stylebox_override("disabled", sb(Color(0.08, 0.1, 0.16, 0.7), 16, Color(0.3, 0.35, 0.45, 0.25), 2, 14))
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)


static func panel(color: Color = C_PANEL, radius: int = 20, pad: int = 18) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", sb(color, radius, Color(1, 1, 1, 0.08), 2, pad))
	return p


static func stat_bar(title: String, value: float, color: Color = C_CYAN, width: float = 150.0) -> HBoxContainer:
	var row := HBoxContainer.new()
	var l := label(title, 22, C_DIM)
	l.custom_minimum_size = Vector2(width, 0)
	row.add_child(l)
	var pb := ProgressBar.new()
	pb.min_value = 0.0
	pb.max_value = 100.0
	pb.value = 0.0
	pb.show_percentage = false
	pb.custom_minimum_size = Vector2(0, 16)
	pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	pb.add_theme_stylebox_override("fill", sb(color, 6))
	row.add_child(pb)
	pb.set_meta("target", value * 100.0)
	return row


static func set_stat_bar(row: HBoxContainer, value: float) -> void:
	var pb: ProgressBar = row.get_child(1) as ProgressBar
	var tw := pb.create_tween()
	tw.tween_property(pb, "value", clampf(value, 0.0, 1.0) * 100.0, 0.3).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


static func spacer(h: float = 0.0, expand: bool = false) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if expand:
		c.size_flags_vertical = Control.SIZE_EXPAND_FILL
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return c


## Margin aman (notch/lubang kamera) dalam koordinat viewport: (kiri, atas, kanan, bawah).
static func safe_margins(vp: Vector2, base: Vector4 = Vector4(28, 20, 28, 20)) -> Vector4:
	var m: Vector4 = base
	if OS.has_feature("mobile"):
		var safe: Rect2i = DisplayServer.get_display_safe_area()
		var win: Vector2i = DisplayServer.window_get_size()
		if win.x > 0 and win.y > 0 and safe.size.x > 0:
			var sx: float = vp.x / float(win.x)
			var sy: float = vp.y / float(win.y)
			m.x += maxf(0.0, float(safe.position.x)) * sx
			m.z += maxf(0.0, float(win.x - safe.position.x - safe.size.x)) * sx
			m.y += maxf(0.0, float(safe.position.y)) * sy
			m.w += maxf(0.0, float(win.y - safe.position.y - safe.size.y)) * sy
	return m


static func fill(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


static func pop(n: Control) -> void:
	if not n.is_inside_tree():
		return
	n.pivot_offset = n.size * 0.5
	n.scale = Vector2(1.18, 1.18)
	var tw := n.create_tween()
	tw.tween_property(n, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## Tombol panah (kiri/kanan) yang digambar lewat kode.
class ArrowButton extends Button:
	var dir: int = 1

	func _init() -> void:
		focus_mode = Control.FOCUS_NONE
		custom_minimum_size = Vector2(72, 72)

	func _draw() -> void:
		var c: Vector2 = size * 0.5
		var s: float = minf(size.x, size.y) * 0.2
		var pts := PackedVector2Array()
		if dir > 0:
			pts = PackedVector2Array([c + Vector2(-s * 0.6, -s), c + Vector2(s * 0.9, 0.0), c + Vector2(-s * 0.6, s)])
		else:
			pts = PackedVector2Array([c + Vector2(s * 0.6, -s), c + Vector2(-s * 0.9, 0.0), c + Vector2(s * 0.6, s)])
		var col := Color(1, 1, 1, 0.95) if not disabled else Color(1, 1, 1, 0.2)
		draw_colored_polygon(pts, col)


static func arrow_button(dir: int, cb: Callable) -> Button:
	var b := ArrowButton.new()
	b.dir = dir
	b.pressed.connect(_click_sound)
	if cb.is_valid():
		b.pressed.connect(cb)
	return b


## Ikon koin emas.
class CoinIcon extends Control:
	func _init() -> void:
		custom_minimum_size = Vector2(34, 34)
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var c: Vector2 = size * 0.5
		var r: float = minf(size.x, size.y) * 0.5 - 1.0
		draw_circle(c, r, Color(0.72, 0.5, 0.05))
		draw_circle(c, r - 2.5, Color(1.0, 0.8, 0.22))
		draw_arc(c, r * 0.58, 0.0, TAU, 24, Color(0.78, 0.55, 0.05), 2.5, true)


## Baris pilihan [<] nilai [>] untuk pengaturan.
static func option_row(title: String, options: Array, current: int, on_change: Callable) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.custom_minimum_size = Vector2(0, 72)
	var t := label(title, 26, C_TEXT)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(t)
	var state := [current]
	var val := label(str(options[current]), 26, C_CYAN, HORIZONTAL_ALIGNMENT_CENTER)
	val.custom_minimum_size = Vector2(190, 0)
	var left := arrow_button(-1, Callable())
	var right := arrow_button(1, Callable())
	left.pressed.connect(func() -> void:
		state[0] = (int(state[0]) - 1 + options.size()) % options.size()
		val.text = str(options[int(state[0])])
		on_change.call(int(state[0])))
	right.pressed.connect(func() -> void:
		state[0] = (int(state[0]) + 1) % options.size()
		val.text = str(options[int(state[0])])
		on_change.call(int(state[0])))
	row.add_child(left)
	row.add_child(val)
	row.add_child(right)
	return row
