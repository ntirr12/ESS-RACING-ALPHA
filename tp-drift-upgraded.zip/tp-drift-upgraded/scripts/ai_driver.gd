extends RefCounted
## Pengemudi AI: pure-pursuit pada garis tengah + profil kecepatan tikungan.

var skill: float = 0.9
var rubber: float = 1.0
var lane: float = 0.0
var look_scale: float = 1.0


func _init(skill_val: float = 0.9, lane_offset: float = 0.0) -> void:
	skill = skill_val
	lane = lane_offset


func drive(car, _delta: float) -> void:
	var track = car.track
	if track == null:
		return
	var n: int = track.count
	var idx: int = car.track_idx
	var sp: float = car.spd
	var look: int = int((3.0 + sp / 110.0) * look_scale)
	var li: int = (idx + look) % n
	var tgt: Vector2 = track.pts[li] + track.nors[li] * lane
	var d: Vector2 = tgt - car.global_position
	var diff: float = wrapf(d.angle() - car.rotation, -PI, PI)
	car.in_steer = clampf(diff * 2.2, -1.0, 1.0)
	var ahead: int = maxi(2, int(sp / 90.0))
	var cap: float = float(car.stats["max"]) * skill * rubber
	var v_goal: float = minf(cap, float(track.corner_speed[(idx + ahead) % n]) * skill * rubber)
	car.in_throttle = 1.0 if sp < v_goal else 0.0
	car.in_brake = sp > v_goal * 1.12
	car.in_hb = false
	car.in_nitro = car.nitro > 80.0 and v_goal >= cap * 0.98 and skill >= 0.95
