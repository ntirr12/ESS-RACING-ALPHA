extends Control
## Pengaturan: audio, kontrol, grafis, data.

const UIKit := preload("res://scripts/ui_kit.gd")

var menu = null
var _reset_armed: bool = false
var _reset_btn: Button = null


func _ready() -> void:
	var root := VBoxContainer.new()
	add_child(root)
	UIKit.fill(root)

	var head := HBoxContainer.new()
	root.add_child(head)
	head.add_child(UIKit.button("KEMBALI", 26, 0, Vector2(200, 64), func() -> void: menu.go("main")))
	var t := UIKit.label("PENGATURAN", 46, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	head.add_child(UIKit.spacer(0))

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 12)
	sc.add_child(col)

	var vol: Array = ["Mati", "10%", "20%", "30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%"]
	_section(col, "AUDIO", [
		UIKit.option_row("Volume musik", vol, int(Save.opt["music"]), _set_music),
		UIKit.option_row("Volume efek", vol, int(Save.opt["sfx"]), _set_sfx),
	])
	_section(col, "KONTROL", [
		UIKit.option_row("Skema kontrol", ["Tombol setir", "Joystick arah"], int(Save.opt["scheme"]), func(i: int) -> void: Save.set_opt("scheme", i)),
		UIKit.option_row("Gas otomatis", ["Nyala", "Mati"], 0 if bool(Save.opt["auto_gas"]) else 1, func(i: int) -> void: Save.set_opt("auto_gas", i == 0)),
		UIKit.option_row("Sensitivitas setir", ["Sangat rendah", "Rendah", "Normal", "Tinggi", "Sangat tinggi"], int(Save.opt["sens"]), func(i: int) -> void: Save.set_opt("sens", i)),
		UIKit.option_row("Getar saat tabrakan", ["Nyala", "Mati"], 0 if bool(Save.opt["vibrate"]) else 1, func(i: int) -> void: Save.set_opt("vibrate", i == 0)),
	])
	_section(col, "GRAFIS & PERFORMA", [
		UIKit.option_row("Kualitas grafis", ["Otomatis", "Rendah", "Sedang", "Tinggi"], int(Save.opt["quality"]) + 1, func(i: int) -> void: Save.set_opt("quality", i - 1)),
		UIKit.option_row("Batas FPS", ["Otomatis", "30 FPS", "60 FPS"], int(Save.opt["fps"]), _set_fps),
		UIKit.option_row("Jarak kamera", ["Dekat", "Normal", "Jauh"], int(Save.opt["zoom"]), func(i: int) -> void: Save.set_opt("zoom", i)),
		UIKit.option_row("Tampilkan FPS", ["Mati", "Nyala"], 1 if bool(Save.opt["show_fps"]) else 0, func(i: int) -> void: Save.set_opt("show_fps", i == 1)),
	])

	var note := UIKit.label("Perubahan grafis berlaku mulai balapan berikutnya. Mode Otomatis memilih kualitas sesuai jumlah inti CPU dan menurunkan efek bila FPS rendah.", 20, UIKit.C_DIM)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(300, 0)
	note.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(note)

	_reset_btn = UIKit.button("RESET SEMUA DATA", 26, 2, Vector2(0, 66), _on_reset)
	col.add_child(_reset_btn)
	col.add_child(UIKit.spacer(20))


func _set_music(i: int) -> void:
	Save.set_opt("music", i)
	Sfx.apply_volumes()


func _set_sfx(i: int) -> void:
	Save.set_opt("sfx", i)
	Sfx.apply_volumes()
	Sfx.play("click")


func _set_fps(i: int) -> void:
	Save.set_opt("fps", i)
	Global.apply_runtime_settings()


func _section(parent: VBoxContainer, title: String, rows: Array) -> void:
	var p := UIKit.panel(UIKit.C_PANEL, 18, 14)
	parent.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	p.add_child(v)
	v.add_child(UIKit.label(title, 22, UIKit.C_PINK))
	for r in rows:
		v.add_child(r)


func _disarm_reset() -> void:
	if is_instance_valid(_reset_btn):
		_reset_armed = false
		_reset_btn.text = "RESET SEMUA DATA"


func _on_reset() -> void:
	if not _reset_armed:
		_reset_armed = true
		_reset_btn.text = "YAKIN? TEKAN LAGI"
		get_tree().create_timer(3.0).timeout.connect(_disarm_reset)
		return
	Save.reset_all()
	Global.selected_car = 0
	Global.selected_map = 0
	Global.remember_selection()
	Sfx.apply_volumes()
	menu.toast("Data direset", UIKit.C_GOLD)
	menu.refresh_coins()
	_reset_armed = false
	_reset_btn.text = "RESET SEMUA DATA"
