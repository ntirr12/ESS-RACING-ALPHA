extends Node2D
## Sesi balapan: membangun dunia, mobil, AI, aturan mode, hasil & hadiah.

const TrackScript := preload("res://scripts/track.gd")
const CarScript := preload("res://scripts/car.gd")
const AIScript := preload("res://scripts/ai_driver.gd")
const HudScript := preload("res://scripts/hud.gd")
const UIKit := preload("res://scripts/ui_kit.gd")

enum State { COUNTDOWN, RACING, FINISHED }

var map_id: int = 0
var map_def: Dictionary = {}
var mode: int = 0
var laps: int = 3
var state: int = State.COUNTDOWN
var race_time: float = 0.0
var drift_left: float = Global.DRIFT_TIME

var track = null
var player = null
var cars: Array = []
var hud = null
var player_rank: int = 1

var _cd: float = 3.2
var _cd_shown: int = 4
var _skid_layer: Node2D
var _skids: Array = []
var _max_skids: int = 30
var _rank_t: float = 0.0
var _wrong_t: float = 0.0
var _finished_order: Array = []
var _perf_t: float = 0.0
var _perf_low: int = 0
var _perf_done: bool = false
var _ended: bool = false
var _sens: Array = [0.7, 0.85, 1.0, 1.15, 1.3]


func _ready() -> void:
	map_id = Global.selected_map
	map_def = Global.MAPS[map_id]
	mode = Global.selected_mode
	laps = Global.laps
	var q: int = Save.quality()
	_max_skids = [10, 18, 30][q]
	var night: float = float(map_def["night"])

	var cm := CanvasModulate.new()
	cm.color = Color(String(map_def["ambient"]))
	add_child(cm)

	track = TrackScript.new()
	add_child(track)
	track.build(map_def, q)

	_skid_layer = Node2D.new()
	add_child(_skid_layer)

	_spawn_cars(q, night)

	hud = HudScript.new()
	add_child(hud)
	hud.setup(self)

	Sfx.play_music(String(map_def["music"]))
	Sfx.duck_music(false)
	get_tree().paused = false


func _spawn_cars(q: int, night: float) -> void:
	var zooms: Array = [1.0, 0.85, 0.7]
	var zoom: float = float(zooms[clampi(int(Save.opt["zoom"]), 0, 2)])
	var player_slot: int = 3 if mode == 0 else 0

	player = _make_car(Global.selected_car, Save.car_paint(Global.selected_car), true, q, night, zoom)
	var gp: Dictionary = track.grid_slot(player_slot)
	player.place(gp["pos"], gp["rot"])
	player.lap_crossed.connect(_on_lap)
	player.drift_banked.connect(_on_drift_banked)
	player.drift_failed.connect(_on_drift_failed)
	player.crashed.connect(_on_player_crash)
	cars.append(player)

	if mode == 0:
		var ids: Array = []
		for i in range(Global.CARS.size()):
			if i != Global.selected_car:
				ids.append(i)
		ids.shuffle()
		var slot: int = 0
		for k in range(mini(3, ids.size())):
			var c = _make_car(int(ids[k]), randi() % Global.PAINTS.size(), false, q, night, zoom)
			c.stats = player.stats.duplicate()
			c.grip_cur = float(c.stats["grip"])
			var skill: float = float(Global.DIFFICULTY_SKILL[Global.difficulty]) * randf_range(0.96, 1.02)
			c.ai = AIScript.new(skill, randf_range(-45.0, 45.0))
			var gs: Dictionary = track.grid_slot(slot)
			slot += 1
			c.place(gs["pos"], gs["rot"])
			c.lap_crossed.connect(_on_lap)
			cars.append(c)


func _make_car(id: int, paint: int, is_p: bool, q: int, night: float, zoom: float):
	var c = CarScript.new()
	c.track = track
	c.setup(id, paint, is_p, q, night, zoom)
	c.dust_color = Color(String(map_def["dust"]))
	c.skid_factory = Callable(self, "_new_skid")
	add_child(c)
	return c


func _new_skid() -> Line2D:
	var ln := Line2D.new()
	ln.width = 9.0
	ln.default_color = Color(0.02, 0.02, 0.02, 0.5)
	ln.begin_cap_mode = Line2D.LINE_CAP_ROUND
	ln.end_cap_mode = Line2D.LINE_CAP_ROUND
	ln.z_index = -5
	_skid_layer.add_child(ln)
	_skids.append(ln)
	while _skids.size() > _max_skids:
		var old: Line2D = _skids.pop_front()
		if is_instance_valid(old):
			old.queue_free()
	return ln


# ------------------------------------------------------------------ loop utama
func _physics_process(delta: float) -> void:
	_apply_player_input()
	match state:
		State.COUNTDOWN:
			_tick_countdown(delta)
		State.RACING:
			race_time += delta
			if mode == 2:
				drift_left -= delta
				if drift_left <= 0.0:
					drift_left = 0.0
					_end_session()
		State.FINISHED:
			pass
	_update_ai(delta)
	_update_rank(delta)
	_update_wrong_way(delta)
	_update_perf(delta)


func _tick_countdown(delta: float) -> void:
	_cd -= delta
	var n: int = ceili(_cd)
	if n != _cd_shown:
		_cd_shown = n
		if n >= 1 and n <= 3:
			hud.countdown(str(n))
			Sfx.play("beep")
		elif n <= 0:
			_go()


func _go() -> void:
	state = State.RACING
	hud.countdown("GO!")
	Sfx.play("go")
	for c in cars:
		c.locked = false
	player.scoring_enabled = true


func _apply_player_input() -> void:
	if player == null or hud == null:
		return
	if state == State.FINISHED and player.ai != null:
		return
	var st: Dictionary = hud.get_input(player.rotation)
	var steer: float = float(st["steer"])
	var gas: float = float(st["gas"])
	var brake: bool = bool(st["brake"])
	var hb: bool = bool(st["hb"])
	var nit: bool = bool(st["nitro"])
	# papan ketik (untuk uji coba di desktop)
	var kx: float = 0.0
	if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
		kx -= 1.0
	if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		kx += 1.0
	if kx != 0.0:
		steer = kx
	if Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W):
		gas = 1.0
	if Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S):
		brake = true
	if Input.is_key_pressed(KEY_SPACE):
		hb = true
	if Input.is_key_pressed(KEY_SHIFT):
		nit = true
	var mult: float = float(_sens[clampi(int(Save.opt["sens"]), 0, 4)])
	player.in_steer = clampf(steer * mult, -1.0, 1.0)
	player.in_throttle = gas
	player.in_brake = brake
	player.in_hb = hb
	player.in_nitro = nit


func _update_ai(delta: float) -> void:
	for c in cars:
		if c == player:
			continue
		if c.ai != null:
			var gap: float = player.progress - c.progress
			if not c.finished:
				c.ai.rubber = clampf(1.0 + gap * 0.0018, 0.9, 1.06)
			if c.stuck_time > 2.5 and not c.locked:
				var i2: int = (c.track_idx + 2) % track.count
				c.place(track.pts[i2], track.tans[i2].angle())
				c.stuck_time = 0.0
	if player.stuck_time > 5.0:
		hud.hint("Macet? Tekan tombol reset (panah melingkar).")


func respawn_player() -> void:
	if state == State.COUNTDOWN or player == null:
		return
	var i: int = track.nearest_global(player.global_position)
	player.place(track.pts[i], track.tans[i].angle())
	player.stuck_time = 0.0
	player.request_shake(6.0)


func _score_of(c) -> float:
	if c.finished:
		return 1.0e9 - c.finish_time
	return c.progress


func _update_rank(delta: float) -> void:
	_rank_t -= delta
	if _rank_t > 0.0:
		return
	_rank_t = 0.15
	if mode != 0:
		player_rank = 1
		return
	var sorted: Array = cars.duplicate()
	sorted.sort_custom(func(a, b) -> bool: return _score_of(a) > _score_of(b))
	player_rank = sorted.find(player) + 1


func _update_wrong_way(delta: float) -> void:
	if state != State.RACING or player.locked:
		return
	var dirv: float = Vector2.from_angle(player.rotation).dot(track.tans[player.track_idx])
	if dirv < -0.3 and player.spd > 120.0:
		_wrong_t += delta
	else:
		_wrong_t = maxf(0.0, _wrong_t - delta * 2.0)
	hud.set_wrong_way(_wrong_t > 1.0)


func _update_perf(delta: float) -> void:
	if _perf_done or int(Save.opt["quality"]) >= 0 or state != State.RACING:
		return
	_perf_t += delta
	if _perf_t < 1.0:
		return
	_perf_t = 0.0
	if Engine.get_frames_per_second() < 40:
		_perf_low += 1
	else:
		_perf_low = maxi(0, _perf_low - 1)
	if _perf_low >= 5:
		_perf_done = true
		_max_skids = 8
		for c in cars:
			c.reduce_effects()


# ------------------------------------------------------------------ event
func _on_lap(car, wraps: int) -> void:
	if state == State.COUNTDOWN:
		return
	var maxw: int = int(car.get_meta("maxw", -1))
	if wraps <= maxw:
		return
	car.set_meta("maxw", wraps)
	if wraps == 0:
		car.lap_mark = race_time
		return
	if mode == 2:
		return
	var lt: float = race_time - car.lap_mark
	car.lap_mark = race_time
	car.lap_times.append(lt)
	var is_best: bool = lt < car.best_lap
	car.best_lap = minf(car.best_lap, lt)
	if car == player:
		hud.on_lap(wraps, lt, is_best)
	if wraps >= laps and not car.finished:
		car.finished = true
		car.finish_time = race_time
		_finished_order.append(car)
		if car == player:
			_end_session()


func _on_drift_banked(points: int, mult: int) -> void:
	hud.flash("+%s  x%d" % [Global.fmt_int(points), mult], UIKit.C_GREEN)


func _on_drift_failed() -> void:
	hud.flash("DRIFT GAGAL", UIKit.C_RED)


func _on_player_crash(impact: float, _car: Node) -> void:
	if impact > 300.0:
		hud.punch_vignette()


# ------------------------------------------------------------------ akhir sesi
func _end_session() -> void:
	if _ended:
		return
	_ended = true
	state = State.FINISHED
	player.scoring_enabled = false
	player.bank_chain()
	player.in_nitro = false
	player.ai = AIScript.new(0.55, 0.0)
	player.locked = false

	var res: Dictionary = {"mode": mode, "map": map_id}
	var place: int = 1
	if mode == 0:
		place = _finished_order.find(player) + 1
		if place <= 0:
			place = player_rank
	var medal: int = 0
	var key: String = str(map_id)
	var new_record: bool = false
	var best_lap_v: float = player.best_lap
	if mode != 2:
		if is_inf(best_lap_v):
			best_lap_v = 0.0
		var prev: float = float(Save.best_lap.get(key, INF))
		if best_lap_v > 0.0 and best_lap_v < prev:
			Save.best_lap[key] = best_lap_v
			new_record = true
	if mode == 1:
		medal = Global.lap_medal(map_id, best_lap_v)
	elif mode == 2:
		medal = Global.drift_medal(player.drift_total)
		if player.drift_total > int(Save.best_drift.get(key, 0)):
			Save.best_drift[key] = player.drift_total
			new_record = true
	if mode == 0:
		var pp: int = int(Save.best_place.get(key, 99))
		if place < pp:
			Save.best_place[key] = place
	if player.drift_total > int(Save.best_drift.get(key, 0)) and mode != 2:
		Save.best_drift[key] = player.drift_total

	var coins: int = Global.compute_reward(mode, place, medal, player.drift_total)
	Save.stats["races"] = int(Save.stats.get("races", 0)) + 1
	Save.stats["drift_total"] = int(Save.stats.get("drift_total", 0)) + player.drift_total
	if mode == 0 and place == 1:
		Save.stats["wins"] = int(Save.stats.get("wins", 0)) + 1
	Save.add_coins(coins)

	res["place"] = place
	res["medal"] = medal
	res["time"] = race_time
	res["best_lap"] = best_lap_v
	res["drift"] = player.drift_total
	res["best_chain"] = player.best_chain
	res["coins"] = coins
	res["record"] = new_record
	Global.last_result = res
	var good: bool = (mode == 0 and place <= 2) or (mode != 0 and medal > 0)
	Sfx.play("win" if good else "lose")
	Sfx.duck_music(true)
	hud.show_results(res)


func restart() -> void:
	Global.goto_scene(Global.GAME_SCENE)


func to_menu() -> void:
	Global.goto_scene(Global.MENU_SCENE)


func _notification(what: int) -> void:
	if hud == null:
		return
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		hud.toggle_pause()
	elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if state == State.RACING:
			hud.pause()
