extends CharacterBody2D
## Mobil top-down: fisika arcade drift, efek visual, skor drift, audio mesin.

signal crashed(impact: float, car: Node)
signal drift_banked(points: int, mult: int)
signal drift_failed
signal lap_crossed(car: Node, wraps: int)

const CAR_LEN := 160.0
const ALIGN_K := 2.8          # penstabil sudut drift
const DRIFT_SLIP := 0.21      # rad (~12 derajat)
const GRACE := 1.0            # detik jeda sebelum rantai drift dibank
const KMH := 0.2              # px/s -> "km/h" tampilan

var car_id: int = 0
var stats: Dictionary = {}
var is_player: bool = false
var quality: int = 2
var night: float = 0.0
var base_zoom: float = 0.85
var display_name: String = ""
var dust_color: Color = Color(0.55, 0.42, 0.28)

var track = null                 # Node lintasan (track.gd)
var ai = null                    # AIDriver (opsional)
var skid_factory: Callable = Callable()

# input
var in_steer: float = 0.0
var in_throttle: float = 0.0
var in_brake: bool = false
var in_hb: bool = false
var in_nitro: bool = false
var locked: bool = true
var scoring_enabled: bool = false

# status
var steer: float = 0.0
var grip_cur: float = 9.0
var nitro: float = 35.0
var boosting: bool = false
var on_road: bool = true
var spd: float = 0.0
var slip: float = 0.0
var drifting: bool = false
var lateral_off: float = 0.0
var stuck_time: float = 0.0

# balapan
var track_idx: int = 0
var wraps: int = -1
var progress: float = 0.0
var finished: bool = false
var finish_time: float = 0.0
var lap_times: Array = []
var lap_mark: float = 0.0
var best_lap: float = INF

# skor drift
var drift_total: int = 0
var best_chain: int = 0
var chain_points: float = 0.0
var chain_mult: int = 1
var chain_time: float = 0.0
var grace: float = 0.0

var _body: Sprite2D
var _shadow: Sprite2D
var _cone: Sprite2D
var _brake_l: Sprite2D
var _brake_r: Sprite2D
var _smoke_l: CPUParticles2D
var _smoke_r: CPUParticles2D
var _flame: CPUParticles2D
var _sparks: CPUParticles2D
var _cam: Camera2D = null
var _engine: AudioStreamPlayer = null
var _skid_snd: AudioStreamPlayer = null
var _skid_vol: float = 0.0
var _skid_l: Line2D = null
var _skid_r: Line2D = null
var _cam_off: Vector2 = Vector2.ZERO
var _shake: float = 0.0
var _hit_cd: float = 0.0
var _spark_cd: float = 0.0
var _was_boosting: bool = false
var _pmul: float = 1.0
var _idle_rpm: float = 0.0


func setup(id: int, paint_idx: int, player: bool, q: int, night_amount: float, zoom_val: float) -> void:
	car_id = id
	is_player = player
	quality = q
	night = night_amount
	base_zoom = zoom_val
	stats = Global.car_stats(id, player)
	display_name = String(Global.CARS[id]["name"])
	grip_cur = float(stats["grip"])
	_pmul = [0.4, 0.7, 1.0][clampi(q, 0, 2)]
	collision_layer = 2
	collision_mask = 1
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	_build_visuals(paint_idx)
	_build_collision()
	if player:
		_build_camera()
		_build_audio()


func _build_visuals(paint_idx: int) -> void:
	var tex: Texture2D = load(String(Global.CARS[car_id]["tex"]))
	var sc: float = CAR_LEN / float(tex.get_width())
	var h: float = float(tex.get_height()) * sc

	_shadow = Sprite2D.new()
	_shadow.texture = load("res://assets/fx/shadow.png")
	_shadow.scale = Vector2(CAR_LEN * 1.15 / 192.0, h * 1.5 / 96.0)
	_shadow.position = Vector2(4, 7)
	_shadow.modulate = Color(1, 1, 1, 0.8)
	_shadow.z_index = -1
	add_child(_shadow)

	var add_mat := CanvasItemMaterial.new()
	add_mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD

	if quality >= 1:
		_cone = Sprite2D.new()
		_cone.texture = load("res://assets/fx/cone.png")
		_cone.centered = false
		_cone.offset = Vector2(0, -80)
		_cone.position = Vector2(CAR_LEN * 0.38, 0)
		_cone.scale = Vector2(2.5, 2.3)
		_cone.modulate = Color(1, 0.95, 0.8, 0.12 + 0.75 * night)
		_cone.material = add_mat
		_cone.z_index = -1
		add_child(_cone)

	_body = Sprite2D.new()
	_body.texture = tex
	_body.scale = Vector2(sc, sc)
	var pcols: Array = Global.PAINTS
	_body.modulate = Color(String(pcols[clampi(paint_idx, 0, pcols.size() - 1)]["color"]))
	add_child(_body)

	_brake_l = _make_glow(Vector2(-CAR_LEN * 0.47, -h * 0.3), Color(1, 0.1, 0.1, 0.9), 0.2, add_mat)
	_brake_r = _make_glow(Vector2(-CAR_LEN * 0.47, h * 0.3), Color(1, 0.1, 0.1, 0.9), 0.2, add_mat)
	_make_glow(Vector2(CAR_LEN * 0.46, -h * 0.28), Color(1, 0.97, 0.85, 0.7), 0.16, add_mat)
	_make_glow(Vector2(CAR_LEN * 0.46, h * 0.28), Color(1, 0.97, 0.85, 0.7), 0.16, add_mat)

	# partikel
	_smoke_l = _make_smoke(Vector2(-CAR_LEN * 0.32, -h * 0.34))
	_smoke_r = _make_smoke(Vector2(-CAR_LEN * 0.32, h * 0.34))
	_flame = CPUParticles2D.new()
	_flame.texture = load("res://assets/fx/glow.png")
	_flame.amount = maxi(4, int(22 * _pmul))
	_flame.lifetime = 0.28
	_flame.local_coords = true
	_flame.position = Vector2(-CAR_LEN * 0.52, 0)
	_flame.direction = Vector2(-1, 0)
	_flame.spread = 10.0
	_flame.gravity = Vector2.ZERO
	_flame.initial_velocity_min = 220.0
	_flame.initial_velocity_max = 380.0
	_flame.scale_amount_min = 0.18
	_flame.scale_amount_max = 0.32
	_flame.color = Color(0.4, 0.75, 1.0, 0.9)
	_flame.color_ramp = _ramp([0.0, 0.5, 1.0], [Color(1, 1, 1, 1), Color(1, 0.55, 0.15, 0.8), Color(1, 0.2, 0.05, 0.0)])
	_flame.material = add_mat
	_flame.emitting = false
	_flame.z_index = 1
	add_child(_flame)

	_sparks = CPUParticles2D.new()
	_sparks.texture = load("res://assets/fx/spark.png")
	_sparks.top_level = true
	_sparks.amount = maxi(4, int(14 * _pmul))
	_sparks.lifetime = 0.45
	_sparks.one_shot = true
	_sparks.explosiveness = 0.95
	_sparks.local_coords = false
	_sparks.spread = 180.0
	_sparks.gravity = Vector2.ZERO
	_sparks.initial_velocity_min = 160.0
	_sparks.initial_velocity_max = 480.0
	_sparks.scale_amount_min = 0.4
	_sparks.scale_amount_max = 0.9
	_sparks.color_ramp = _ramp([0.0, 0.4, 1.0], [Color(1, 1, 0.8, 1), Color(1, 0.6, 0.15, 0.9), Color(1, 0.3, 0.05, 0.0)])
	_sparks.material = add_mat
	_sparks.emitting = false
	_sparks.z_index = 3
	add_child(_sparks)


func _make_glow(pos: Vector2, col: Color, scl: float, mat: Material) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = load("res://assets/fx/glow.png")
	s.position = pos
	s.scale = Vector2(scl, scl)
	s.modulate = col
	s.material = mat
	s.z_index = 1
	add_child(s)
	return s


func _ramp(offs: Array, cols: Array) -> Gradient:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array(offs)
	var pc := PackedColorArray()
	for c in cols:
		pc.append(c)
	g.colors = pc
	return g


func _make_smoke(pos: Vector2) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.texture = load("res://assets/fx/smoke.png")
	p.position = pos
	p.amount = maxi(4, int(26 * _pmul))
	p.lifetime = 0.9
	p.local_coords = false
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 8.0
	p.initial_velocity_max = 70.0
	p.scale_amount_min = 0.55
	p.scale_amount_max = 1.0
	var cv := Curve.new()
	cv.min_value = 0.0
	cv.max_value = 2.0
	cv.add_point(Vector2(0.0, 0.5))
	cv.add_point(Vector2(1.0, 1.6))
	p.scale_amount_curve = cv
	p.color = Color(0.85, 0.85, 0.88, 1.0)
	p.color_ramp = _ramp([0.0, 0.15, 1.0], [Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.5), Color(1, 1, 1, 0.0)])
	p.emitting = false
	p.z_index = 2
	add_child(p)
	return p


func _build_collision() -> void:
	var cs := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(CAR_LEN * 0.88, 54.0)
	cs.shape = rect
	add_child(cs)


func _build_camera() -> void:
	_cam = Camera2D.new()
	_cam.zoom = Vector2(base_zoom, base_zoom)
	_cam.position_smoothing_enabled = false
	add_child(_cam)


func _build_audio() -> void:
	_engine = AudioStreamPlayer.new()
	_engine.stream = Sfx.looped("engine")
	_engine.bus = "SFX"
	_engine.volume_db = -11.0
	_engine.pitch_scale = 0.75
	add_child(_engine)
	_skid_snd = AudioStreamPlayer.new()
	_skid_snd.stream = Sfx.looped("skid")
	_skid_snd.bus = "SFX"
	_skid_snd.volume_db = -80.0
	add_child(_skid_snd)
	_engine.autoplay = true


func place(pos: Vector2, rot: float) -> void:
	global_position = pos
	rotation = rot
	velocity = Vector2.ZERO
	steer = 0.0
	grip_cur = float(stats["grip"])
	_end_skid()
	if track != null:
		track_idx = track.nearest_global(pos)
	reset_physics_interpolation()
	if _cam != null:
		_cam.reset_smoothing()
		_cam.reset_physics_interpolation()


func reduce_effects() -> void:
	if _cone != null:
		_cone.visible = false
	for p in [_smoke_l, _smoke_r, _flame, _sparks]:
		p.amount = maxi(2, int(p.amount * 0.5))


func request_shake(amount: float) -> void:
	_shake = maxf(_shake, amount)


# ------------------------------------------------------------------ fisika
func _physics_process(delta: float) -> void:
	_hit_cd = maxf(0.0, _hit_cd - delta)
	_spark_cd = maxf(0.0, _spark_cd - delta)
	if ai != null:
		ai.drive(self, delta)
	_update_track_state()
	if locked:
		_idle(delta)
		return

	var thr: float = in_throttle
	if in_brake:
		thr = 0.0
	var rate: float = 7.0 if absf(in_steer) > absf(steer) else 10.0
	steer = move_toward(steer, in_steer, rate * delta)
	boosting = in_nitro and nitro > 0.5 and thr > 0.0

	var fwd: Vector2 = Vector2.from_angle(rotation)
	var rgt := Vector2(-fwd.y, fwd.x)
	var vf0: float = velocity.dot(fwd)
	var vl0: float = velocity.dot(rgt)
	var maxv_base: float = float(stats["max"])
	var base_grip: float = float(stats["grip"]) * (1.0 if on_road else 0.7)

	# yaw
	var sf: float = clampf(absf(vf0) / 90.0, 0.0, 1.0) * (1.0 - 0.35 * clampf(absf(vf0) / maxv_base, 0.0, 1.0))
	var yaw: float = steer * float(stats["turn"]) * sf * (1.0 if vf0 >= 0.0 else -1.0) * (1.35 if in_hb else 1.0)
	var w: float = clampf((base_grip - grip_cur) / base_grip, 0.0, 1.0)
	if vf0 > 20.0 and Vector2(vf0, vl0).length() > 80.0 and w > 0.0:
		yaw += atan2(vl0, vf0) * ALIGN_K * w
	rotation += yaw * delta

	# longitudinal / lateral pada sumbu baru
	var fwd2: Vector2 = Vector2.from_angle(rotation)
	var rgt2 := Vector2(-fwd2.y, fwd2.x)
	var vf: float = velocity.dot(fwd2)
	var vl: float = velocity.dot(rgt2)
	var np: float = float(stats["nitro_power"])
	var maxv: float = maxv_base * (1.0 if on_road else 0.55)
	var acc: float = float(stats["acc"]) * (1.0 if on_road else 0.6)
	if boosting:
		maxv *= 1.0 + 0.3 * np
		acc *= 1.0 + 0.8 * np
	if thr > 0.0:
		vf += acc * thr * clampf(1.0 - vf / maxv, 0.0, 1.0) * delta
	vf -= vf * 0.04 * delta
	if vf > maxv:
		vf -= (vf - maxv) * 1.5 * delta
	if in_brake:
		if vf > 30.0:
			vf -= 1500.0 * delta
		else:
			vf = maxf(vf - acc * 0.5 * delta, -maxv * 0.3)
	elif thr <= 0.0:
		vf -= signf(vf) * minf(absf(vf), 180.0 * delta)
	if in_hb:
		vf *= 1.0 - 0.30 * delta

	var tgt: float = float(stats["dgrip"]) if in_hb else base_grip
	if (not in_hb) and thr > 0.3 and absf(steer) > 0.4 and absf(vf) > 0.55 * maxv_base:
		tgt *= 1.0 - 0.55 * float(stats["dbias"])
	grip_cur += (tgt - grip_cur) * minf(1.0, (12.0 if in_hb else 3.0) * delta)
	vl *= exp(-grip_cur * delta)
	velocity = fwd2 * vf + rgt2 * vl

	var pre_vel: Vector2 = velocity
	move_and_slide()
	var scraping: bool = _handle_collisions(pre_vel, delta)

	# status pasca-gerak
	var fwd3: Vector2 = Vector2.from_angle(rotation)
	var rgt3 := Vector2(-fwd3.y, fwd3.x)
	var vfn: float = velocity.dot(fwd3)
	var vln: float = velocity.dot(rgt3)
	spd = velocity.length()
	slip = atan2(vln, vfn) if vfn > 1.0 else 0.0
	drifting = absf(slip) > DRIFT_SLIP and spd > 280.0

	_update_nitro(delta)
	_update_drift_score(delta)
	_update_effects(delta, thr, vfn, scraping, fwd3, rgt3)
	_update_camera(delta)
	_update_stuck(delta)


func _idle(delta: float) -> void:
	velocity = Vector2.ZERO
	spd = 0.0
	drifting = false
	if _engine != null:
		_idle_rpm = lerpf(_idle_rpm, in_throttle, 1.0 - exp(-6.0 * delta))
		_engine.pitch_scale = 0.75 + _idle_rpm * 0.9
	if _brake_l != null:
		_set_brake_lights(false)
	_smoke_l.emitting = false
	_smoke_r.emitting = false
	_flame.emitting = false
	_update_camera(delta)


func _handle_collisions(pre_vel: Vector2, delta: float) -> bool:
	if get_slide_collision_count() == 0:
		return false
	var col: KinematicCollision2D = get_slide_collision(0)
	var n: Vector2 = col.get_normal()
	var impact: float = maxf(0.0, -pre_vel.dot(n))
	velocity *= 1.0 - 0.5 * delta
	if impact > 110.0 and _hit_cd <= 0.0:
		_hit_cd = 0.25
		velocity += n * impact * 0.25
		var fwd: Vector2 = Vector2.from_angle(rotation)
		var t: Vector2 = n.orthogonal()
		if t.dot(fwd) < 0.0:
			t = -t
		rotation += fwd.angle_to(t) * clampf(impact / 1000.0, 0.0, 0.4)
		if impact > 260.0:
			velocity *= 0.85
			if chain_points > 0.0:
				_fail_chain()
		_sparks.global_position = col.get_position()
		_sparks.restart()
		_sparks.emitting = true
		crashed.emit(impact, self)
		if is_player:
			request_shake(clampf(impact / 40.0, 4.0, 22.0))
			Sfx.play("crash" if impact > 300.0 else "hit", -2.0, randf_range(0.9, 1.1))
			if impact > 300.0 and bool(Save.opt["vibrate"]):
				Input.vibrate_handheld(int(clampf(impact / 8.0, 30.0, 120.0)))
	elif spd > 250.0 and _spark_cd <= 0.0:
		_spark_cd = 0.12
		_sparks.global_position = col.get_position()
		_sparks.restart()
		_sparks.emitting = true
	return true


func _update_track_state() -> void:
	if track == null:
		return
	var prev: int = track_idx
	track_idx = track.nearest(global_position, track_idx)
	var cnt: int = track.count
	var d: int = track_idx - prev
	if d < -cnt / 2:
		wraps += 1
		lap_crossed.emit(self, wraps)
	elif d > cnt / 2:
		wraps -= 1
	lateral_off = track.lateral(global_position, track_idx)
	on_road = absf(lateral_off) <= track.half_w + 18.0
	var frac: float = clampf((global_position - track.pts[track_idx]).dot(track.tans[track_idx]) / track.step_len, -0.5, 0.5)
	progress = float(wraps * cnt + track_idx) + frac


func _update_stuck(delta: float) -> void:
	if spd < 40.0 and in_throttle > 0.0:
		stuck_time += delta
	else:
		stuck_time = 0.0


# ------------------------------------------------------------------ nitro & skor
func _update_nitro(delta: float) -> void:
	if boosting:
		nitro = maxf(0.0, nitro - 34.0 * delta)
		if not _was_boosting:
			if is_player:
				Sfx.play("nitro", -3.0)
				request_shake(5.0)
	else:
		nitro = minf(100.0, nitro + 2.5 * float(stats["nitro_regen"]) * delta)
	_was_boosting = boosting


func _update_drift_score(delta: float) -> void:
	if not (scoring_enabled and is_player):
		return
	var ok: bool = drifting and on_road
	if ok:
		chain_time += delta
		grace = GRACE
		chain_points += spd / 100.0 * rad_to_deg(absf(slip)) * 1.2 * delta
		var m: int = mini(1 + int(chain_time / 2.5), 8)
		if m > chain_mult and is_player:
			Sfx.play("combo", -6.0, 0.9 + 0.08 * m)
		chain_mult = m
		nitro = minf(100.0, nitro + 16.0 * float(stats["nitro_regen"]) * delta)
	elif chain_points > 0.0:
		grace -= delta
		if grace <= 0.0:
			bank_chain()


func bank_chain() -> void:
	if chain_points <= 0.0:
		return
	var pts_i: int = int(chain_points * float(chain_mult))
	drift_total += pts_i
	best_chain = maxi(best_chain, pts_i)
	drift_banked.emit(pts_i, chain_mult)
	_reset_chain()


func _fail_chain() -> void:
	drift_failed.emit()
	_reset_chain()


func _reset_chain() -> void:
	chain_points = 0.0
	chain_mult = 1
	chain_time = 0.0
	grace = 0.0


func chain_display() -> int:
	return int(chain_points * float(chain_mult))


# ------------------------------------------------------------------ efek
func _set_brake_lights(on: bool) -> void:
	var a: float = 1.0 if on else 0.35
	_brake_l.modulate.a = a
	_brake_r.modulate.a = a
	_brake_l.scale = Vector2(0.3, 0.3) if on else Vector2(0.2, 0.2)
	_brake_r.scale = _brake_l.scale


func _update_effects(delta: float, thr: float, vf: float, scraping: bool, fwd: Vector2, rgt: Vector2) -> void:
	_set_brake_lights(in_brake or (thr <= 0.0 and vf > 100.0))
	var smoking: bool = drifting or (not on_road and spd > 150.0)
	if not on_road:
		_smoke_l.color = dust_color
		_smoke_r.color = dust_color
	else:
		_smoke_l.color = Color(0.85, 0.85, 0.88, 1.0)
		_smoke_r.color = _smoke_l.color
	_smoke_l.emitting = smoking
	_smoke_r.emitting = smoking
	_flame.emitting = boosting

	# jejak ban
	if drifting and on_road:
		_extend_skid(fwd, rgt)
	else:
		_end_skid()

	# audio
	if _engine != null:
		var rpm: float = clampf(absf(vf) / float(stats["max"]), 0.0, 1.3)
		var target_pitch: float = 0.7 + rpm * 1.8 + (0.18 if boosting else 0.0)
		_engine.pitch_scale = lerpf(_engine.pitch_scale, target_pitch, 1.0 - exp(-12.0 * delta))
		_engine.volume_db = -12.0 + thr * 3.0 + (2.0 if boosting else 0.0)
		var want: float = 0.0
		if drifting and on_road:
			want = clampf(absf(slip) / 0.7, 0.25, 1.0)
		elif scraping and spd > 300.0:
			want = 0.35
		_skid_vol = lerpf(_skid_vol, want, 1.0 - exp(-10.0 * delta))
		if _skid_vol > 0.03:
			if not _skid_snd.playing:
				_skid_snd.play()
			_skid_snd.volume_db = linear_to_db(_skid_vol) - 7.0
		elif _skid_snd.playing:
			_skid_snd.stop()


func _extend_skid(fwd: Vector2, rgt: Vector2) -> void:
	if not skid_factory.is_valid():
		return
	var rear: Vector2 = global_position - fwd * 52.0
	var pl: Vector2 = rear - rgt * 25.0
	var pr: Vector2 = rear + rgt * 25.0
	if _skid_l == null:
		_skid_l = skid_factory.call()
		_skid_r = skid_factory.call()
	if _skid_l == null or _skid_r == null:
		return
	if _skid_l.get_point_count() == 0 or _skid_l.points[_skid_l.get_point_count() - 1].distance_squared_to(pl) > 100.0:
		_skid_l.add_point(pl)
		_skid_r.add_point(pr)


func _end_skid() -> void:
	_skid_l = null
	_skid_r = null


func _update_camera(delta: float) -> void:
	if _cam == null:
		return
	var look: Vector2 = (velocity * 0.2).limit_length(230.0)
	_cam_off = _cam_off.lerp(look, 1.0 - exp(-5.0 * delta))
	_shake = maxf(0.0, _shake - 55.0 * delta)
	var jitter := Vector2.ZERO
	if _shake > 0.1:
		jitter = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake
	_cam.offset = _cam_off + jitter
	var ratio: float = clampf(spd / float(stats["max"]), 0.0, 1.3)
	var z: float = base_zoom * (1.0 - 0.14 * ratio - (0.06 if boosting else 0.0))
	_cam.zoom = _cam.zoom.lerp(Vector2(z, z), 1.0 - exp(-2.5 * delta))
