extends Node2D
## Latar menu: aspal gelap + mobil drift melingkar tanpa henti.

var _ground: Sprite2D
var _car_root: Node2D
var _car: Sprite2D
var _smoke_l: CPUParticles2D
var _smoke_r: CPUParticles2D
var _center: Vector2 = Vector2(800, 380)
var _radius: float = 235.0
var _ang: float = 0.0
var _vig: TextureRect


func _ready() -> void:
	_ground = Sprite2D.new()
	_ground.texture = load("res://assets/tex/asphalt.png")
	_ground.centered = false
	_ground.region_enabled = true
	_ground.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	_ground.modulate = Color(0.5, 0.52, 0.62)
	_ground.scale = Vector2(2, 2)
	add_child(_ground)

	_car_root = Node2D.new()
	add_child(_car_root)
	_smoke_l = _make_smoke()
	_smoke_r = _make_smoke()
	_car = Sprite2D.new()
	_car.scale = Vector2(1.25, 1.25)
	_car_root.add_child(_car)
	var shadow := Sprite2D.new()
	shadow.texture = load("res://assets/fx/shadow.png")
	shadow.scale = Vector2(2.4, 1.5)
	shadow.position = Vector2(8, 14)
	shadow.z_index = -1
	_car_root.add_child(shadow)

	_vig = TextureRect.new()
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	g.colors = PackedColorArray([Color(0.02, 0.03, 0.07, 0.0), Color(0.02, 0.03, 0.07, 0.25), Color(0.02, 0.03, 0.07, 0.95)])
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	_vig.texture = gt
	_vig.stretch_mode = TextureRect.STRETCH_SCALE
	_vig.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_vig.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vig.z_index = 20
	add_child(_vig)

	set_car(Global.selected_car)
	get_viewport().size_changed.connect(_on_resize)
	_on_resize()


func _make_smoke() -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.texture = load("res://assets/fx/smoke.png")
	p.amount = 40 if Save.quality() > 0 else 20
	p.lifetime = 1.4
	p.local_coords = false
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 10.0
	p.initial_velocity_max = 60.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 1.8
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.15, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 0.45), Color(1, 1, 1, 0)])
	p.color_ramp = g
	p.z_index = 3
	p.emitting = true
	_car_root.add_child(p)
	return p


func set_car(id: int) -> void:
	_car.texture = load(String(Global.CARS[id]["tex"]))
	var pc: Array = Global.PAINTS
	_car.modulate = Color(String(pc[Save.car_paint(id)]["color"]))
	_smoke_l.position = Vector2(-95, -38)
	_smoke_r.position = Vector2(-95, 38)


func _on_resize() -> void:
	var vs: Vector2 = get_viewport_rect().size
	_ground.region_rect = Rect2(Vector2.ZERO, vs / 2.0 + Vector2(512, 512))
	_center = Vector2(vs.x * 0.68, vs.y * 0.52)
	_radius = minf(vs.x, vs.y) * 0.33
	_vig.position = Vector2.ZERO
	_vig.size = vs
	queue_redraw()


func _process(delta: float) -> void:
	_ang += delta * 1.0
	var pos: Vector2 = _center + Vector2.from_angle(_ang) * _radius
	_car_root.position = pos
	_car_root.rotation = _ang + PI * 0.5 + 0.55
	_smoke_l.emitting = true
	_smoke_r.emitting = true


func _draw() -> void:
	draw_arc(_center, _radius, 0.0, TAU, 96, Color(0, 0, 0, 0.4), 34.0, true)
	draw_arc(_center, _radius + 12.0, 0.0, TAU, 96, Color(0, 0, 0, 0.22), 22.0, true)
