extends Node
## Data game (mobil, map, mode), konfigurasi sesi, dan perpindahan scene.

const VERSION := "1.0.0"
const MENU_SCENE := "res://scenes/menu.tscn"
const GAME_SCENE := "res://scenes/game.tscn"
const TILE := 512.0            # ukuran dunia untuk 1 ubin tekstur
const MAX_UPGRADE := 5
const DRIFT_TIME := 120.0
const DRIFT_MEDALS := [3000, 9000, 18000]        # perunggu, perak, emas
const LAP_MEDAL_MULT := [1.55, 1.30, 1.12]       # x waktu referensi lap
const DIFFICULTY_NAMES := ["Mudah", "Normal", "Sulit"]
const DIFFICULTY_SKILL := [0.80, 0.90, 0.99]
const MODE_NAMES := ["Balapan", "Time Attack", "Drift Challenge"]
const MODE_DESC := [
	"Lawan 3 mobil AI. Finis di posisi terbaik untuk koin terbanyak.",
	"Sendirian di lintasan. Kejar lap tercepat dan raih medali.",
	"120 detik. Drift beruntun untuk menaikkan pengganda skor.",
]
const MEDAL_NAMES := ["-", "PERUNGGU", "PERAK", "EMAS"]

# nilai: max = kecepatan puncak (px/s), acc = akselerasi, grip = cengkeram normal,
# dgrip = cengkeram saat handbrake, turn = laju belok (rad/s), dbias = kemudahan power-slide
const CARS: Array = [
	{"name": "Bayern GTR", "tag": "SERBAGUNA", "tex": "res://assets/cars/car_0.png", "price": 0,
	 "max": 840.0, "acc": 560.0, "grip": 9.0, "dgrip": 2.0, "turn": 2.7, "dbias": 0.5,
	 "desc": "Stabil dan mudah dikendalikan. Pilihan pas untuk belajar drift."},
	{"name": "Kaiser RS", "tag": "HANDLING", "tex": "res://assets/cars/car_1.png", "price": 2500,
	 "max": 900.0, "acc": 640.0, "grip": 9.5, "dgrip": 2.2, "turn": 2.9, "dbias": 0.4,
	 "desc": "Tajam di tikungan dengan akselerasi keluar yang kuat."},
	{"name": "Nebula F8", "tag": "OVERSTEER", "tex": "res://assets/cars/car_2.png", "price": 4500,
	 "max": 1000.0, "acc": 700.0, "grip": 8.0, "dgrip": 1.7, "turn": 2.5, "dbias": 0.8,
	 "desc": "Ekor mudah melebar. Kencang dan paling liar saat drift."},
	{"name": "Phantom One", "tag": "HYPERCAR", "tex": "res://assets/cars/car_3.png", "price": 7500,
	 "max": 1080.0, "acc": 800.0, "grip": 8.4, "dgrip": 1.8, "turn": 2.7, "dbias": 0.6,
	 "desc": "Kecepatan puncak tertinggi dengan tenaga brutal."},
]

const UPGRADES: Array = [
	{"id": "engine", "name": "Mesin", "desc": "Kecepatan puncak & akselerasi", "base": 300},
	{"id": "tires", "name": "Ban", "desc": "Grip & kelincahan belok", "base": 250},
	{"id": "nitro", "name": "Nitro", "desc": "Tenaga & pengisian nitro", "base": 200},
]

const PAINTS: Array = [
	{"name": "Asli", "color": "#ffffff"},
	{"name": "Merah", "color": "#ff7070"},
	{"name": "Kuning", "color": "#ffd94a"},
	{"name": "Hijau", "color": "#6dff8f"},
	{"name": "Cyan", "color": "#6fe7ff"},
	{"name": "Ungu", "color": "#c88cff"},
	{"name": "Arang", "color": "#5a5a66"},
]

# deco: [jenis, jumlah, jarak_min_dari_dinding, jarak_max, ukuran_min, ukuran_maks]
const MAPS: Array = [
	{"id": "speedway", "name": "Sirkuit Speedway", "price": 0, "stars": 1, "ref_lap": 42.0,
	 "desc": "Sirkuit siang hari yang lebar dengan tikungan menyapu dan hairpin ketat.",
	 "width": 280.0, "shoulder": 80.0, "ground": "grass", "ground_tint": "#ffffff",
	 "road_tint": "#ffffff", "kerb1": "#e63232", "kerb2": "#f2f2f2", "line": "#f4f4f4",
	 "barrier": "rw", "kerbs": true, "night": 0.0, "ambient": "#ffffff", "glow": "#ffffff",
	 "dust": "#8c6b45", "music": "music_race", "lamps": false, "neon": false,
	 "deco": [["tree", 300, 120, 1300, 170, 290], ["tree2", 220, 120, 1300, 150, 250],
			  ["bush", 260, 70, 800, 60, 110], ["rock", 90, 70, 900, 50, 100]],
	 "pts": [[1496,0],[2992,0],[4216,170],[5168,748],[5440,1632],[4896,2448],[3944,2652],[3128,2244],[2584,1564],[1768,1360],[952,1836],[748,2652],[1496,3400],[2856,3604],[4352,3740],[5576,3400],[6324,2584],[6392,1360],[5984,408],[4896,-612],[3264,-952],[1496,-884],[-68,-884],[-510,-442],[-68,0]]},
	{"id": "akina", "name": "Gunung Akina", "price": 1200, "stars": 3, "ref_lap": 40.0,
	 "desc": "Jalur gunung sempit penuh hairpin. Senja, pagar pengaman, tanpa ampun.",
	 "width": 210.0, "shoulder": 50.0, "ground": "forest", "ground_tint": "#ffe9d2",
	 "road_tint": "#d8d8e0", "kerb1": "#f2f2f2", "kerb2": "#f2f2f2", "line": "#ffe9a0",
	 "barrier": "gg", "kerbs": false, "night": 0.30, "ambient": "#ffd7b5", "glow": "#ffb060",
	 "dust": "#6b4a2d", "music": "music_race2", "lamps": false, "neon": false,
	 "deco": [["pine", 520, 90, 1400, 150, 260], ["pine", 260, 90, 600, 120, 190],
			  ["rock", 160, 60, 900, 60, 130], ["bush", 160, 60, 600, 55, 95]],
	 "pts": [[900,0],[1400,0],[1900,0],[2070,46],[2194,170],[2240,340],[2194,510],[2070,634],[1900,680],[1520,680],[1140,680],[760,680],[380,680],[0,680],[-170,726],[-294,850],[-340,1020],[-294,1190],[-170,1314],[0,1360],[380,1360],[760,1360],[1140,1360],[1520,1360],[1900,1360],[2070,1406],[2194,1530],[2240,1700],[2194,1870],[2070,1994],[1900,2040],[1520,2040],[1140,2040],[760,2040],[380,2040],[0,2040],[-170,2086],[-294,2210],[-340,2380],[-294,2550],[-170,2674],[0,2720],[380,2720],[760,2720],[1140,2720],[1520,2720],[1900,2720],[3000,2700],[3900,2200],[4400,900],[4000,-500],[3000,-1300],[1800,-1400],[1400,-1400],[1000,-1400],[600,-1400],[200,-1400],[-200,-1400],[-600,-1400],[-868,-1347],[-1095,-1195],[-1247,-968],[-1300,-700],[-1247,-432],[-1095,-205],[-868,-53],[-600,0],[-225,0],[150,0],[525,0]]},
	{"id": "harbor", "name": "Neon Harbor", "price": 2500, "stars": 2, "ref_lap": 45.5,
	 "desc": "Pelabuhan malam dengan lampu neon, kontainer, dan sapuan lebar kecepatan tinggi.",
	 "width": 300.0, "shoulder": 70.0, "ground": "concrete", "ground_tint": "#c4d0ff",
	 "road_tint": "#d0d4f0", "kerb1": "#19e6ff", "kerb2": "#ff2d95", "line": "#bff6ff",
	 "barrier": "yb", "kerbs": true, "night": 0.85, "ambient": "#7684c4", "glow": "#4fd8ff",
	 "dust": "#8a8a96", "music": "music_race", "lamps": true, "neon": true,
	 "deco": [["container", 170, 110, 1000, 150, 150], ["roof", 40, 260, 1200, 360, 620]],
	 "pts": [[0,0],[1584,0],[3168,0],[4752,66],[5940,594],[6468,1584],[6138,2640],[5148,3168],[4224,2838],[3696,2112],[2904,1914],[2112,2376],[1980,3300],[2772,4092],[3960,4356],[5280,4290],[6204,4884],[6336,5808],[5412,6336],[3828,6204],[2112,6204],[660,5808],[-396,4884],[-792,3564],[-660,1980],[-462,792]]},
	{"id": "mesa", "name": "Gurun Mesa", "price": 4000, "stars": 2, "ref_lap": 43.5,
	 "desc": "Lintasan gurun berpasir dengan sapuan cepat dan hairpin panjang di bawah terik.",
	 "width": 260.0, "shoulder": 80.0, "ground": "sand", "ground_tint": "#ffffff",
	 "road_tint": "#e6d9c8", "kerb1": "#ff8a1f", "kerb2": "#f2f2f2", "line": "#f6ecd2",
	 "barrier": "rw", "kerbs": true, "night": 0.0, "ambient": "#fff0d8", "glow": "#ffffff",
	 "dust": "#c9a468", "music": "music_race2", "lamps": false, "neon": false,
	 "deco": [["rock", 320, 90, 1500, 70, 190], ["bush", 220, 70, 1000, 50, 95],
			  ["tree2", 40, 150, 1400, 130, 190]],
	 "pts": [[0,0],[1632,-136],[3128,-612],[4488,-204],[5304,816],[5168,2040],[4216,2720],[3264,2448],[2720,1632],[1904,1496],[1224,2176],[1360,3264],[2312,3944],[3536,4216],[4760,4760],[5168,5848],[4352,6664],[2856,6800],[1496,6324],[272,5576],[-816,4488],[-1360,3128],[-1360,1632],[-952,544]]},
]

# --- sesi ---
var selected_car: int = 0
var selected_map: int = 0
var selected_mode: int = 0
var laps: int = 3
var difficulty: int = 1
var last_result: Dictionary = {}

var _fade: ColorRect
var _changing: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	selected_car = clampi(int(Save.opt["car"]), 0, CARS.size() - 1)
	selected_map = clampi(int(Save.opt["map"]), 0, MAPS.size() - 1)
	selected_mode = clampi(int(Save.opt["mode"]), 0, 2)
	laps = int(Save.opt["laps"])
	difficulty = clampi(int(Save.opt["diff"]), 0, 2)
	if not Save.has_car(selected_car):
		selected_car = 0
	if not Save.has_map(selected_map):
		selected_map = 0
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_fade = ColorRect.new()
	_fade.color = Color(0.02, 0.03, 0.06, 0.0)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(_fade)
	apply_runtime_settings()


func apply_runtime_settings() -> void:
	match int(Save.opt["fps"]):
		1:
			Engine.max_fps = 30
		2:
			Engine.max_fps = 60
		_:
			Engine.max_fps = 0


func goto_scene(path: String) -> void:
	if _changing:
		return
	_changing = true
	get_tree().paused = false
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", 1.0, 0.22)
	await tw.finished
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween()
	tw2.tween_property(_fade, "color:a", 0.0, 0.28)
	await tw2.finished
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_changing = false


func remember_selection() -> void:
	Save.opt["car"] = selected_car
	Save.opt["map"] = selected_map
	Save.opt["mode"] = selected_mode
	Save.opt["laps"] = laps
	Save.opt["diff"] = difficulty
	Save.save_game()


func quit_game() -> void:
	Save.save_game()
	get_tree().quit()


# --- statistik mobil setelah upgrade ---
func car_stats(id: int, upgraded: bool = true) -> Dictionary:
	var base: Dictionary = CARS[id]
	var up: Array = Save.car_upgrades(id) if upgraded else [0, 0, 0]
	var e: int = int(up[0])
	var t: int = int(up[1])
	var n: int = int(up[2])
	return {
		"max": float(base["max"]) * (1.0 + 0.04 * e),
		"acc": float(base["acc"]) * (1.0 + 0.05 * e),
		"grip": float(base["grip"]) * (1.0 + 0.035 * t),
		"dgrip": float(base["dgrip"]),
		"turn": float(base["turn"]) * (1.0 + 0.025 * t),
		"dbias": float(base["dbias"]),
		"nitro_power": 1.0 + 0.10 * n,
		"nitro_regen": 1.0 + 0.18 * n,
	}


func upgrade_cost(id: int, upg_index: int) -> int:
	var lvl: int = int(Save.car_upgrades(id)[upg_index])
	return int(UPGRADES[upg_index]["base"]) * (lvl + 1)


# --- medali & hadiah ---
func lap_medal(map_id: int, lap_time: float) -> int:
	var ref: float = float(MAPS[map_id]["ref_lap"])
	if lap_time <= 0.0:
		return 0
	if lap_time <= ref * LAP_MEDAL_MULT[2]:
		return 3
	if lap_time <= ref * LAP_MEDAL_MULT[1]:
		return 2
	if lap_time <= ref * LAP_MEDAL_MULT[0]:
		return 1
	return 0


func drift_medal(score: int) -> int:
	if score >= DRIFT_MEDALS[2]:
		return 3
	if score >= DRIFT_MEDALS[1]:
		return 2
	if score >= DRIFT_MEDALS[0]:
		return 1
	return 0


func compute_reward(mode: int, place: int, medal: int, drift_score: int) -> int:
	var coins: int = 0
	match mode:
		0:
			var table: Array = [900, 600, 380, 220]
			coins = int(table[clampi(place - 1, 0, 3)])
		1:
			coins = 150 + [0, 120, 260, 500][medal]
		2:
			coins = int(drift_score / 14.0) + [0, 100, 250, 500][medal]
	if mode != 2:
		coins += int(drift_score / 120.0)
	return coins


func fmt_time(t: float) -> String:
	if t <= 0.0 or is_inf(t):
		return "--:--.--"
	var m: int = int(t / 60.0)
	var s: float = t - m * 60.0
	return "%d:%05.2f" % [m, s]


func fmt_int(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = "." + out
	return ("-" if n < 0 else "") + out
