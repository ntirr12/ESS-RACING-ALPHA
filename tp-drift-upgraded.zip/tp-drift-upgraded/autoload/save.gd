extends Node
## Penyimpanan progres & pengaturan pemain (user://).

signal coins_changed(value: int)

const PATH := "user://tpdrift_save.cfg"

var coins: int = 300
var owned_cars: Array = [0]
var owned_maps: Array = [0]
var upgrades: Dictionary = {}    # "car_id" -> [mesin, ban, nitro]
var paints: Dictionary = {}      # "car_id" -> indeks cat
var best_lap: Dictionary = {}    # "map_id" -> detik
var best_drift: Dictionary = {}  # "map_id" -> skor
var best_place: Dictionary = {}  # "map_id" -> posisi terbaik (1..4)
var stats: Dictionary = {"races": 0, "drift_total": 0, "wins": 0}
var seen_tutorial: bool = false

# Pengaturan
var opt: Dictionary = {
	"music": 7,       # 0..10
	"sfx": 9,         # 0..10
	"scheme": 0,      # 0 = tombol, 1 = joystick
	"auto_gas": true,
	"sens": 2,        # 0..4 (sensitivitas setir)
	"vibrate": true,
	"quality": -1,    # -1 = otomatis, 0 rendah, 1 sedang, 2 tinggi
	"fps": 0,         # 0 = otomatis, 1 = 30, 2 = 60
	"show_fps": false,
	"zoom": 1,        # 0 dekat, 1 normal, 2 jauh
	"car": 0,         # pilihan terakhir
	"map": 0,
	"mode": 0,
	"laps": 3,
	"diff": 1,
}


func _ready() -> void:
	load_game()


func auto_quality() -> int:
	var cores: int = OS.get_processor_count()
	if cores <= 4:
		return 0
	if cores <= 6:
		return 1
	return 2


func quality() -> int:
	var q: int = int(opt["quality"])
	return auto_quality() if q < 0 else q


func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	coins = int(cfg.get_value("save", "coins", coins))
	owned_cars = _to_int_array(cfg.get_value("save", "owned_cars", owned_cars))
	owned_maps = _to_int_array(cfg.get_value("save", "owned_maps", owned_maps))
	var u: Variant = cfg.get_value("save", "upgrades", upgrades)
	if u is Dictionary:
		upgrades = u
	var p: Variant = cfg.get_value("save", "paints", paints)
	if p is Dictionary:
		paints = p
	var bl: Variant = cfg.get_value("save", "best_lap", best_lap)
	if bl is Dictionary:
		best_lap = bl
	var bd: Variant = cfg.get_value("save", "best_drift", best_drift)
	if bd is Dictionary:
		best_drift = bd
	var bp: Variant = cfg.get_value("save", "best_place", best_place)
	if bp is Dictionary:
		best_place = bp
	var st: Variant = cfg.get_value("save", "stats", stats)
	if st is Dictionary:
		stats = st
	seen_tutorial = bool(cfg.get_value("save", "seen_tutorial", false))
	var o: Variant = cfg.get_value("save", "opt", opt)
	if o is Dictionary:
		for k in o.keys():
			if opt.has(k):
				opt[k] = o[k]
	if not owned_cars.has(0):
		owned_cars.append(0)
	if not owned_maps.has(0):
		owned_maps.append(0)


func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("save", "coins", coins)
	cfg.set_value("save", "owned_cars", owned_cars)
	cfg.set_value("save", "owned_maps", owned_maps)
	cfg.set_value("save", "upgrades", upgrades)
	cfg.set_value("save", "paints", paints)
	cfg.set_value("save", "best_lap", best_lap)
	cfg.set_value("save", "best_drift", best_drift)
	cfg.set_value("save", "best_place", best_place)
	cfg.set_value("save", "stats", stats)
	cfg.set_value("save", "seen_tutorial", seen_tutorial)
	cfg.set_value("save", "opt", opt)
	cfg.save(PATH)


func reset_all() -> void:
	coins = 300
	owned_cars = [0]
	owned_maps = [0]
	upgrades = {}
	paints = {}
	best_lap = {}
	best_drift = {}
	best_place = {}
	stats = {"races": 0, "drift_total": 0, "wins": 0}
	seen_tutorial = false
	save_game()
	coins_changed.emit(coins)


func _to_int_array(v: Variant) -> Array:
	var out: Array = []
	if v is Array:
		for x in v:
			out.append(int(x))
	return out


# --- koin ---
func add_coins(n: int) -> void:
	coins += n
	coins_changed.emit(coins)
	save_game()


func spend(n: int) -> bool:
	if coins < n:
		return false
	coins -= n
	coins_changed.emit(coins)
	save_game()
	return true


# --- mobil ---
func has_car(id: int) -> bool:
	return owned_cars.has(id)


func has_map(id: int) -> bool:
	return owned_maps.has(id)


func car_upgrades(id: int) -> Array:
	var key := str(id)
	if not upgrades.has(key):
		upgrades[key] = [0, 0, 0]
	return upgrades[key]


func car_paint(id: int) -> int:
	return int(paints.get(str(id), 0))


func set_car_paint(id: int, idx: int) -> void:
	paints[str(id)] = idx
	save_game()


# --- opsi ---
func get_opt(key: String) -> Variant:
	return opt[key]


func set_opt(key: String, value: Variant) -> void:
	opt[key] = value
	save_game()
