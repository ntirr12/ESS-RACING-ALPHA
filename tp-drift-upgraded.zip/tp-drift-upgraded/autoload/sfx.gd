extends Node
## Manajer audio: bus Music/SFX, pool pemutar SFX, musik loop.

const SOUNDS := {
	"click": "res://assets/audio/click.wav",
	"select": "res://assets/audio/select.wav",
	"error": "res://assets/audio/error.wav",
	"buy": "res://assets/audio/buy.wav",
	"beep": "res://assets/audio/beep.wav",
	"go": "res://assets/audio/go.wav",
	"combo": "res://assets/audio/combo.wav",
	"lap": "res://assets/audio/lap.wav",
	"crash": "res://assets/audio/crash.wav",
	"hit": "res://assets/audio/hit.wav",
	"nitro": "res://assets/audio/nitro.wav",
	"win": "res://assets/audio/win.wav",
	"lose": "res://assets/audio/lose.wav",
	"engine": "res://assets/audio/engine.wav",
	"skid": "res://assets/audio/skid.wav",
}
const MUSIC := {
	"music_menu": "res://assets/audio/music_menu.ogg",
	"music_race": "res://assets/audio/music_race.ogg",
	"music_race2": "res://assets/audio/music_race2.ogg",
}

var _streams: Dictionary = {}
var _music_streams: Dictionary = {}
var _pool: Array[AudioStreamPlayer] = []
var _music: AudioStreamPlayer
var _current_music: String = ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_bus("Music")
	_ensure_bus("SFX")
	for key in SOUNDS.keys():
		var res: Resource = load(SOUNDS[key])
		if res is AudioStream:
			_streams[key] = res
	for i in range(10):
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	_music.volume_db = -4.0
	add_child(_music)
	apply_volumes()


func _ensure_bus(bus_name: String) -> void:
	if AudioServer.get_bus_index(bus_name) != -1:
		return
	AudioServer.add_bus()
	var idx: int = AudioServer.bus_count - 1
	AudioServer.set_bus_name(idx, bus_name)
	AudioServer.set_bus_send(idx, "Master")


func apply_volumes() -> void:
	_set_bus("Music", float(Save.opt["music"]) / 10.0)
	_set_bus("SFX", float(Save.opt["sfx"]) / 10.0)


func _set_bus(bus_name: String, linear: float) -> void:
	var idx: int = AudioServer.get_bus_index(bus_name)
	if idx < 0:
		return
	AudioServer.set_bus_mute(idx, linear <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(linear, 0.001)))


func play(sound: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	var s: AudioStream = _streams.get(sound)
	if s == null:
		return
	var chosen: AudioStreamPlayer = null
	for p in _pool:
		if not p.playing:
			chosen = p
			break
	if chosen == null:
		chosen = _pool[0]
	chosen.stream = s
	chosen.volume_db = volume_db
	chosen.pitch_scale = pitch
	chosen.play()


## Mengembalikan salinan stream yang di-loop (untuk mesin & decit ban).
func looped(sound: String) -> AudioStream:
	var s: AudioStream = _streams.get(sound)
	if s == null:
		return null
	var d: AudioStream = s.duplicate() as AudioStream
	if d is AudioStreamWAV:
		var w: AudioStreamWAV = d as AudioStreamWAV
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = int(w.data.size() * 0.5)
	return d


func play_music(track: String) -> void:
	if _current_music == track and _music.playing:
		return
	if not _music_streams.has(track):
		var res: Resource = load(MUSIC[track]) if MUSIC.has(track) else null
		if res is AudioStreamOggVorbis:
			var ogg: AudioStreamOggVorbis = (res as AudioStreamOggVorbis).duplicate() as AudioStreamOggVorbis
			ogg.loop = true
			_music_streams[track] = ogg
		else:
			return
	_current_music = track
	_music.stream = _music_streams[track]
	_music.play()


func stop_music() -> void:
	_current_music = ""
	_music.stop()


func duck_music(low: bool) -> void:
	var tw := create_tween()
	tw.tween_property(_music, "volume_db", -14.0 if low else -4.0, 0.25)
