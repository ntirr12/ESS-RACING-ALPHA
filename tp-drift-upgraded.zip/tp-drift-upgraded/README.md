# TP Drift — Top-Down Drift Racing (Godot 4)

Game drift top-down untuk mobile, dibangun ulang dari proyek `tp-drift` awal.
Renderer: **GL Compatibility** (paling luas didukung perangkat Android, termasuk kelas low-end).

## Fitur
- **Menu utama** dengan latar animasi (mobil drift melingkar + asap), transisi fade, koin.
- **Garasi**: 4 mobil (dari gambar milik Anda), statistik, **upgrade** (Mesin / Ban / Nitro, 5 level), **cat** 7 warna, beli dengan koin.
- **4 lintasan prosedural** (spline Catmull-Rom): Speedway (siang), Gunung Akina (senja, hairpin), Neon Harbor (malam, neon + lampu), Gurun Mesa. Lintasan dibuka dengan koin.
- **3 mode**: Balapan vs 3 AI (tingkat kesulitan, 2–8 lap), Time Attack (medali), Drift Challenge (120 dtk, medali skor).
- **Fisika drift arcade**: grip dinamis, handbrake, power-slide, penstabil sudut drift, rumput memperlambat, tabrakan dinding dengan percikan api.
- **Skor drift + kombo** (hingga x8), **nitro** yang terisi dari drift.
- **HUD**: speedometer, nitro, lap/waktu/posisi, minimap, countdown, "arah salah", popup kombo, jeda, layar hasil dengan hadiah koin.
- **Efek**: asap ban, debu, jejak ban, percikan, api nitro, lampu depan/rem, bayangan, vinyet kecepatan, guncangan kamera, getar, zoom dinamis.
- **Audio**: mesin berpitch dinamis, decit ban, SFX UI/balap, 2 musik loop (semua disintesis, bukan aset berhak cipta).
- **Kontrol sentuh** multi-touch: tombol setir, atau joystick arah (skema asli). Gas otomatis opsional. Papan ketik untuk uji di desktop.
- **Penyimpanan** progres & pengaturan di `user://`.

## Kontrol desktop (untuk uji coba)
`A/D` atau panah = setir · `W` gas · `S` rem · `Space` = DRIFT (handbrake) · `Shift` = nitro · `Esc/P` = jeda · `R` = reset ke jalur.
Mouse otomatis berperan sebagai satu sentuhan.

## Optimasi mobile yang diterapkan
- Gambar mobil 3470×2306 px (±32 MB VRAM tiap gambar) → 320 px dan dibersihkan (bayangan sisa dibuang).
- Seluruh jalan, kerb, garis, dan tanah dirender sebagai **satu mesh per lapisan** (bukan ratusan node).
- Dekorasi (pohon, batu, kontainer, lampu) memakai **MultiMesh**: satu draw call per jenis.
- Tanpa shader kustom, tanpa post-processing; efek memakai `CPUParticles2D` dan sprite aditif.
- Kualitas **Otomatis** (berdasarkan jumlah inti CPU) + penurunan efek otomatis bila FPS < 40; opsi Rendah/Sedang/Tinggi, batas FPS 30/60.
- `physics_interpolation` aktif → gerak mulus di layar 90/120 Hz.
- Pencarian posisi trek memakai jendela lokal (bukan scan penuh) dan grid spasial untuk dekorasi.
- Tekstur diatur kompres ETC2/ASTC; orientasi sensor-landscape; layar tetap menyala; dukungan area aman (notch).
- Perbaikan bug proyek lama: autoload `Global` belum terdaftar, path `Car.tscn` salah huruf besar, mode gerak `GROUNDED` diganti `FLOATING` untuk top-down.

## Struktur
```
autoload/   save.gd  global.gd (data mobil/map/mode)  sfx.gd
scenes/     menu.tscn  game.tscn            (hanya penampung script; UI dibangun lewat kode)
scripts/    menu*.gd  garage_panel.gd  map_panel.gd  settings_panel.gd  ui_kit.gd
            game.gd  car.gd  track.gd  ai_driver.gd  hud.gd
assets/     cars/ tex/ fx/ audio/
```

## Menyetel keseimbangan
- Stat mobil, harga, peta, medali, hadiah: `autoload/global.gd` (`CARS`, `MAPS`, `DRIFT_MEDALS`, `LAP_MEDAL_MULT`, `compute_reward`).
- Rasa kemudi: `scripts/car.gd` (`ALIGN_K`, `DRIFT_SLIP`, grip/yaw di `_physics_process`).
- Kesulitan AI: `DIFFICULTY_SKILL` di `global.gd`, rubber-band di `game.gd::_update_ai`.
- Titik kontrol lintasan: `pts` di `MAPS` (jaga radius tikungan > lebar jalan/2 + bahu agar dinding tidak melipat).

## Menjalankan & export Android
1. Buka folder ini di Godot 4.x (proyek dibuat untuk 4.7), tunggu import aset selesai.
2. Jalankan (F5). Scene utama: `scenes/menu.tscn`.
3. Export Android: pasang Android build template + SDK, pilih arsitektur `arm64-v8a`, aktifkan "Use Gradle Build" bila perlu.
